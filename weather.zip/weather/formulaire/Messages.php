﻿<?php
// Déclaration des paramètres de connexion
$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";

// Connexion au serveur
$connect = mysqli_connect($host,$user,$passwd) or die("erreur de connexion au serveur");

mysqli_select_db($connect, $bdd) or die("erreur de connexion a la base de donnees");

//////// Creation des requetes ////////


//Toutes les données
$Tout = mysqli_query($connect, "SELECT Message.* FROM Message,Station WHERE (Message.ID = Station.id_station) AND (DATE(Message.DT_serveur) = CURRENT_DATE()) ORDER BY `Message`.`DT_serveur`  DESC") or die('erreur requete 1');
?>

<html>
    <head><title>Formulaire de saisie </title></head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="datatables/jquery.dataTables.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="../assets/css/style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>

    input[type=button] {
        width: 30%;
        background-color: #2164f3;
        color: white;
        padding: 12px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=button]:hover {
        background-color: #184dbf;
    }

    div.total {
        border-radius: 5px;
        background-color: #f2f2f2;
        font-family: "Source Sans Pro", "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    }

    body {
      padding: 20px 20px;
      background-color:#f4f4f4;
      background-size: cover;
    }

    td {
      text-align: center;
      border-bottom: 1px solid #dbdbdb;
    }
    th {
    }

    .myBtn2 {
      display: block;
      position: fixed;
      bottom: 10px;
      right: 10px;
      z-index: 99;
      font-size: 18px;
      border: none;
      outline: none;
      background: url("../assets/img/ICON3.png") no-repeat;
      background-size:cover;
      color: white;
      cursor: pointer;
      padding: 40px 40px;
    }


    .myBtn {
      display: block;
      position: fixed;
      bottom: 10px;
      left: 10px;
      z-index: 99;
      font-size: 18px;
      border: none;
      outline: none;
      background: url("../assets/img/ICON2.png") no-repeat;
      background-size:cover;
      color: white;
      cursor: pointer;
      padding: 40px 40px;
    }

    .total {
        border-radius: 5px;
        box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);
    }

    #loader {
      position: absolute;
      right: 20px;
      top: 30px;
      z-index: 1001;
      border: 7px solid #f4f4f4;
      border-radius: 50%;
      border-top: 7px solid #3498db;
      border-bottom: 7px solid #3498db;
      width: 50px;
      height: 50px;
      -webkit-animation: spin 1s ease infinite;
      animation: spin 1s ease infinite;
    }

    #loader2 {
      position: absolute;
      right: 30px;
      top: 40px;
      z-index: 1001;
      border: 4px solid #f4f4f4;
      border-radius: 50%;
      border-top: 4px solid grey;
      border-bottom: 4px solid grey;
      width: 30px;
      height: 30px;
      -webkit-animation: spin 1s linear infinite;
      animation: spin 1s linear infinite;
    }

    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    /* Add animation to "page content" */
    .animate-bottom {
      position: relative;
      -webkit-animation-name: animatebottom;
      -webkit-animation-duration: 1s;
      animation-name: animatebottom;
      animation-duration: 1s
    }

    @-webkit-keyframes animatebottom {
      from { bottom:-100px; opacity:0 }
      to { bottom:0px; opacity:1 }
    }

    @keyframes animatebottom {
      from{ bottom:-100px; opacity:0 }
      to{ bottom:0; opacity:1 }
    }

    #myDiv {
      display: none;
    }
    #myDiv2 {
      display: none;
    }


</style>

<body onload="myFunction()">

<div id="loader"></div>
<div id="loader2"></div>

  <button onclick="location.href='../index.php';" class="myBtn"></button>
  <button onClick="window.location.reload()" class="myBtn2"></button>

<div class="total animate-bottom" id="myDiv" style="margin-bottom: 100px;">

<div class="row">
  <div class="block">
    <div class="block-header">
      <h3 class="block-title">Trames reçues<small>&nbsp;
    </small></h3>
</div>
<div class="block-content">
<!-- DataTables init on table by adding .js-dataTable-full-pagination class, functionality initialized in js/pages/base_tables_datatables.js -->
<table  id="example" class="table table-bordered table-hover table-striped js-dataTable-full-pagination">
<thead>
  <tr>
    <th class="text-center" >id_message</th>
    <th class="text-center" >DT_serveur</th>
    <th class="text-center" >ID</th>
    <th class="text-center" >IDp</th>
    <th class="text-center" >TS</th>
    <th class="text-center" >DT</th>
    <th class="text-center" >D1</th>
    <th class="text-center" >D2</th>
    <th class="text-center" >D3</th>
    <th class="text-center" >Source</th>
  </tr>
</thead>
<tbody>
  <?php
    while($row = mysqli_fetch_array($Tout))
    {
       echo '
        <tr>
          <td>'.$row["id_message"].'</td>
          <td>'.$row["DT_serveur"].'</td>
          <td>'.$row["ID"].'</td>
          <td>'.$row["IDp"].'</td>
          <td>'.$row["TS"].'</td>
          <td>'.$row["DT"].'</td>
          <td style="color:#f39c12;">'.$row["D1"].'</td>
          <td style="color:#00c0ef;">'.$row["D2"].'</td>
          <td style="color:#0073b7;">'.$row["D3"].'</td>
          <td>'.$row["Source"].'</td>
        </tr>
       ';
    }
  ?>
</tbody>
<tfoot>
  <tr>
    <th class="text-center" >id_message</th>
    <th class="text-center" >DT_serveur</th>
    <th class="text-center" >Micro-Station</th>
    <th class="text-center" >IDp</th>
    <th class="text-center" >TS</th>
    <th class="text-center" >DT</th>
    <th class="text-center" >D1</th>
    <th class="text-center" >D2</th>
    <th class="text-center" >D3</th>
    <th class="text-center" >Source</th>
  </tr>
</tfoot>
</table>
</div>
</div>
</div>
</div>


<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/pages/base_tables_datatables.js"></script>
<script src="datatables/jquery.dataTables.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>

<script> //pour le loader
var myVar;

function myFunction() {
    myVar = setTimeout(showPage, 1000); //temps en ([secondes]000)
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("loader2").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>

<script>
$(document).ready( function () {

  var table = $('#example').DataTable({
		"order": [[ 1, "desc" ]],
		"oLanguage": {
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ items."
		}
	});

    $("#example tfoot th").each( function ( i ) {

		if ($(this).text() !== '') {
	        var isStatusColumn = (($(this).text() == 'Status') ? true : false);
			var select = $('<select><option value=""></option></select>')
	            .appendTo( $(this).empty() )
	            .on( 'change', function () {
	                var val = $(this).val();

	                table.column( i )
	                    .search( val ? '^'+$(this).val()+'$' : val, true, false )
	                    .draw();
	            } );

			// Get the Status values a specific way since the status is a anchor/image
			if (isStatusColumn) {
				var statusItems = [];

                /* ### IS THERE A BETTER/SIMPLER WAY TO GET A UNIQUE ARRAY OF <TD> data-filter ATTRIBUTES? ### */
				table.column( i ).nodes().to$().each( function(d, j){
					var thisStatus = $(j).attr("data-filter");
					if($.inArray(thisStatus, statusItems) === -1) statusItems.push(thisStatus);
				} );

				statusItems.sort();

				$.each( statusItems, function(i, item){
				    select.append( '<option value="'+item+'">'+item+'</option>' );
				});

			}
            // All other non-Status columns (like the example)
			else {
				table.column( i ).data().unique().sort().each( function ( d, j ) {
					select.append( '<option value="'+d+'">'+d+'</option>' );
		        } );
			}

		}
    } );

} );

</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>

</body>
</html>
