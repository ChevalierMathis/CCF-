<?php

// Variables d'accès
$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";

// Connexion à la base de donnée
$connect = mysqli_connect($host,$user,$passwd, $bdd) or die("Impossible de se connecter à la base de données.");


$ID=$_POST['ID'];
$IDp=$_POST['IDp'];
$TS=$_POST['TS'];
$DT=$_POST['DT'];
$D1=$_POST['D1'];
$D2=$_POST['D2'];
$D3=$_POST['D3'];	
 
// Insertion du message
$requete = "INSERT INTO Message (ID,IDp,TS,DT,D1,D2,D3,Source) VALUES (".$ID.",".$IDp.",".$TS.",".$DT.",".$D1.",".$D2.",".$D3.",'Formulaire');";
$result = mysqli_query($connect,$requete);
mysqli_free_result($result);

// Mise a jour du statut de la station
$requete1 = "UPDATE Station SET Station.statut = 1 WHERE Station.id_station = ".$ID.";";
$result1 = mysqli_query($connect,$requete1);
mysqli_free_result($result1);
 
switch($DT)
{
    // Type de donnée 0x0001
    case 1: 
        {
            $D1 = ($D1 / 10) - 40;
            
            $requete2 = "INSERT INTO Mesure (id_station,id_passerelle,type_mesure,valeur) VALUES (".$ID.",".$IDp.",'Temperature',".$D1."),(".$ID.",".$IDp.",'Humidite',".$D2."),(".$ID.",".$IDp.",'Precipitation',".$D3.");";
            $result2 = mysqli_query($connect,$requete2);
            mysqli_free_result($result2);

            break;
        }
    
    // Type de donnée 0x00FF
    case 255:
        {
            /*$stationName = $D1 . $D2 . $D3;
            
            $requete = "UPDATE station SET statut = 1, nom_station = ".$stationName."";
            $result = mysqli_query($connect,$requete);*/
            
            break;
        }
        
    // Type de donnée inconnu
    default:
        {
            echo("Type de donnees inconnu !");
        }
}
?>
