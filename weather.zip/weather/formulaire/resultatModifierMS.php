<!DOCTYPE html>
<html>
<head>
<style>

    body {
      padding: 20px 20px;
      background-color:#f4f4f4;
      background-size:cover;
      font-family: 'Lato', Calibri, Arial, sans-serif;
    }

    td {
      text-align: center;
      border-bottom: 1px solid #dbdbdb;
    }
    th {
    }

    .total {
        background-color: #ffffff;
        border-radius: 5px;
        box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);
        text-align: center;
        padding: 10px;
    }

    @media (min-width: 1000px) {
      .total {
      margin-right: 14%;
      margin-left: 14%;
      margin-top: 20px;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
      border-radius: 6px;
      background-color: white;
      padding: 10px;
      }

      h3 {
        font-size: 30px;
      }

      h4 {
        font-size: 20px
      }
    }

    @media (max-width:1000px) {
      .total {
      margin-right: 10px;
      margin-left: 10px;
      margin-top: 20px;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
      border-radius: 6px;
      background-color: white;
      padding: 10px;
      }

      h3 {
        font-size: 40px
      }

      h4 {
        font-size: 30px
      }
    }

    #loader {
      position: absolute;
      left: 50%;
      top: 50%;
      z-index: 100;
      width: 120px;
      height: 120px;
      margin: -75px 0 0 -75px;
      z-index: 1001;
      border: 7px solid white;
      border-radius: 50%;
      border-top: 7px solid #3498db;
      border-bottom: 7px solid #3498db;
      -webkit-animation: spin 1s ease infinite;
      animation: spin 1s ease infinite;
      text-align: center;
    }

    #loader2 {
      position: absolute;
      left: 50%;
      top: 50%;
      z-index: 100;
      width: 100px;
      height: 100px;
      margin: -65px 0 0 -65px;
      z-index: 1001;
      border: 7px solid white;
      border-radius: 50%;
      border-top: 7px solid grey;
      border-right: 7px solid grey;
      -webkit-animation: spin 1s linear infinite;
      animation: spin 1s linear infinite;
      text-align: center;
    }

    #loader3 {
      position: absolute;
      left: 50%;
      top: 50%;
      z-index: 100;
      width: 80px;
      height: 80px;
      margin: -55px 0 0 -55px;
      z-index: 1001;
      border: 7px solid white;
      border-radius: 50%;
      border-top: 7px solid #c9c9c9;
      border-right: 7px solid #c9c9c9;
      -webkit-animation: spin 2s linear infinite;
      animation: spin 2s linear infinite;
      text-align: center;
    }

    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    /* Add animation to "page content" */
    .animate-bottom {
      position: relative;
      -webkit-animation-name: animatebottom;
      -webkit-animation-duration: 1s;
      animation-name: animatebottom;
      animation-duration: 1s
    }

    @-webkit-keyframes animatebottom {
      from { bottom:-100px; opacity:0 }
      to { bottom:0px; opacity:1 }
    }

    @keyframes animatebottom {
      from{ bottom:-100px; opacity:0 }
      to{ bottom:0; opacity:1 }
    }
</style>
</head>
<body onload="myFunction()">

<?php


$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";


$connect = mysqli_connect($host,$user,$passwd, $bdd) or die("Impossible de se connecter à la base de données.");

$id_station=$_GET['ID'];
$id_station2=$_POST['slot_ID'];
$nom_station=$_POST['slot_NOM'];
$latitude=$_POST['slot_LAT'];
$longitude=$_POST['slot_LON'];
$region=$_POST['slot_REG'];
$departement=$_POST['slot_DEP'];
$localisation=$_POST['slot_LOC'];
$id_capteurs=$_POST['slot_CAP'];
$date_fabrication=$_POST['slot_DATE'];
$mdp=$_POST['slot_MDP'];

if($mdp=="weather"){
  $requete = "UPDATE Station
  SET id_station=".$id_station2.",
  nom_station='".$nom_station."',
  latitude=".$latitude.",
  longitude=".$longitude.",
  region='".$region."',
  departement='".$departement."',
  localisation='".$localisation."',
  id_capteurs=".$id_capteurs.",
  date_fabrication='".$date_fabrication."' WHERE `Station`.`id_station` = ".$id_station."";

    $result = mysqli_query($connect,$requete);
    if($result==1){
?>



<div class="total animate-bottom" id="myDiv">
        <h3 class="block-title" style="color:#0073b7;">Modification en cours</h3>
        <div id="loader"></div>
        <div id="loader2"></div>
        <div id="loader3"></div>
        <h3 class="block-title" style="color:#646464;margin-top:200px;">Vous allez être redirigé vers la page d'accueil</h3>
</div>


<script> //pour le loader
var myVar;

function myFunction() {
    myVar = setTimeout(goBack, 4000); //temps en ([secondes]000)
}

function goBack() {
    location.href='../index.php';
}
</script>

<?php
  }
  else{
?>

<div class="total animate-bottom" id="myDiv">
        <h3 class="block-title" style="color:#e10500;">Erreur de requête</h3>
        <div id="loader" style="border-top: 7px solid #e10500; border-bottom: 7px solid #e10500;"></div>
        <div id="loader2"></div>
        <div id="loader3"></div>
        <h3 class="block-title" style="color:#646464;margin-top:200px;">Vous allez être redirigé vers la page précédente</h3>
        <h4 class="block-title" style="color:#646464;margin-top:2px;">Veillez à bien remplir les champs selon le type de données</h4>
</div>

<script> //pour le loader
var myVar;

function myFunction() {
    myVar = setTimeout(goBack, 4000); //temps en ([secondes]000)
}

function goBack() {
    window.history.back();
}
</script>

<?php
  }
}
else{
?>

<div class="total animate-bottom" id="myDiv">
        <h3 class="block-title" style="color:#e10500;">Mot de Passe Incorrect</h3>
        <div id="loader" style="border-top: 7px solid #e10500; border-bottom: 7px solid #e10500;"></div>
        <div id="loader2"></div>
        <div id="loader3"></div>
        <h3 class="block-title" style="color:#646464;margin-top:200px;">Vous allez être redirigé vers la page précédente</h3>
</div>


<script> //pour le loader
var myVar;

function myFunction() {
    myVar = setTimeout(goBack, 4000); //temps en ([secondes]000)
}

function goBack() {
    window.history.back();
}
</script>

<?php
}

?>


</body>
