<?php

$idStation = $_GET["idStation"];
// Déclaration des paramètres de connexion
$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";


// Connexion au serveur
$connect = mysqli_connect($host,$user,$passwd) or die("erreur de connexion au serveur");

mysqli_select_db($connect, $bdd) or die("erreur de connexion a la base de donnees");

//////// Creation des requetes ////////
$totalMS = mysqli_query($connect, "SELECT id_station FROM Station") or die('erreur requete 222');
?>

<html>
    <head><title>Formulaire de saisie</title></head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<style>
    input[type=text], select {
        width: 100%;
        padding: 12px 20px;
        margin: 3px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type=int], select {
        width: 100%;
        padding: 12px 20px;
        margin: 3px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type=float], select {
        width: 100%;
        padding: 12px 20px;
        margin: 3px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type=submit] {
        width: 100%;
        background-color: #2164f3;
        color: white;
        padding: 12px 20px;
        margin: 3px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=password], select {
        width: 100%;
        padding: 12px 20px;
        margin: 3px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type=submit]:hover {
        background-color: #184dbf;
    }

    div.total {
        border-radius: 5px;
        background-color: #f2f2f2;
        padding: 20px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }

    body {
      background-color:white;
      font-family: 'Lato', Calibri, Arial, sans-serif;
    }

    .myBtn2 {
      display: block;
      position: fixed;
      bottom: 10px;
      left: 10px;
      z-index: 999;
      font-size: 18px;
      border: none;
      outline: none;
      background: url("../assets/img/ICON2.png") no-repeat;
      background-size:cover;
      color: white;
      cursor: pointer;
      padding: 40px 40px;
    }

    @media (min-width: 1000px) {
      body {
        padding: 20px 30%;
        font-size: 18px;
      }
    }

    @media (max-width:1000px) {
      body {
        padding: 20px 3%;
        font-size: 30px;
      }
      input[type=text], select {
          width: 100%;
          padding: 12px 20px;
          margin: 3px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
          font-size:22px;
      }

      input[type=int], select {
          width: 100%;
          padding: 12px 20px;
          margin: 3px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
          font-size:22px;
      }

      input[type=float], select {
          width: 100%;
          padding: 12px 20px;
          margin: 3px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
          font-size:22px;
      }

      input[type=password], select {
          width: 100%;
          padding: 12px 20px;
          margin: 3px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
          font-size:22px;
      }

      input[type=submit] {
          width: 100%;
          background-color: #2164f3;
          color: white;
          padding: 12px 20px;
          margin: 3px 0;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size:22px;
      }
    }

</style>

<body>

<div class="total">

  <h2 style="color:#4c4c4c" align="center">Suppression d'une Micro-Station</h2>
  <form action="http://weather.btslimayrac.ovh/formulaire/resultatSuppressionMS.php" method="POST">


  <br />

<select>
    <?php
        while($row = mysqli_fetch_array($totalMS))
        {
    ?>

        <option name="slot_ID" value="Id"><?php printf("%d",$row[0]);?></option>

    <?php
        }
    ?>
</select>
  <br />
  <br /> <input name="slot_ID" type="int" placeholder="Confirmer l'Id de la Station" required/>
  <br />
  <br /> <input name="slot_MDP" type="password" placeholder="Mot de Passe Utilisateur" required/>
  <br />

  <br /> <input name="valider" type="submit" value="Valider"/>
  <br />
  <div style="color:#4c4c4c; font-size: 12px;" align="center"> Merci de remplir la totalité des champs</div>

</form>
</div>

<button onclick="location.href='../index.php';" class="myBtn2"></button>

</body>
</html>
