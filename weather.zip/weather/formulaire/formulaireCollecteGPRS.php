﻿<?php

// Variables d'accès
$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";

// Connexion à la base de donnée
$connect = mysqli_connect($host,$user,$passwd, $bdd) or die("Impossible de se connecter à la base de données.");

// Récupère les valeurs
$ID=$_GET['ID'];
$IDp="0";
$TS=$_GET['TS'];
$DT=$_GET['DT'];
$D1=$_GET['D1'];
$D2=$_GET['D2'];
$D3=$_GET['D3'];

// Insertion du message
$requete = "INSERT INTO Message (ID,IDp,TS,DT,D1,D2,D3,Source) VALUES (".$ID.",".$IDp.",".$TS.",".$DT.",".$D1.",".$D2.",".$D3.",'GPRS');";
$result = mysqli_query($connect,$requete);
mysqli_free_result($result);

// Mise a jour du statut de la station
$requete1 = "UPDATE Station SET Station.statut = 1 WHERE Station.id_station = ".$ID.";";
$result1 = mysqli_query($connect,$requete1);
mysqli_free_result($result1);


switch($DT)
{
    // Type de donnée 0x0001
    case 1: 
        {
            $D1 = ($D1 / 10) - 40;
            
            $requete2 = "INSERT INTO Mesure (id_station,id_passerelle,type_mesure,valeur) VALUES (".$ID.",".$IDp.",'Temperature',".$D1."),(".$ID.",".$IDp.",'Humidite',".$D2."),(".$ID.",".$IDp.",'Precipitation',".$D3.");";
            $result2 = mysqli_query($connect,$requete2);
            mysqli_free_result($result2);

            break;
        }
    
    // Type de donnée 0x00FF
    case 255:
        {
            /*$stationName = $D1 . $D2 . $D3;
            
            $requete = "UPDATE station SET statut = 1, nom_station = ".$stationName."";
            $result = mysqli_query($connect,$requete);*/
            
            break;
        }
        
    // Type de donnée inconnu
    default:
        {
            echo("Type de donnees inconnu !");
        }
}
?>
