﻿<?php
// Fonctions
function convertNumberToCharacter($number)
{
    switch($number)
    {
        case 0:
            {
                return('A');
                break;
            }

        case 1:
            {
                return('B');
                break;
            }

        case 2:
            {
                return('C');
                break;
            }

        case 3:
            {
                return('D');
                break;
            }

        case 4:
            {
                return('E');
                break;
            }

        case 5:
            {
                return('F');
                break;
            }

        case 6:
            {
                return('G');
                break;
            }

        case 7:
            {
                return('H');
                break;
            }

        case 8:
            {
                return('I');
                break;
            }

        case 9:
            {
                return('J');
                break;
            }

        case 10:
            {
                return('K');
                break;
            }

        case 11:
            {
                return('L');
                break;
            }

        case 12:
            {
                return('M');
                break;
            }

        case 13:
            {
                return('N');
                break;
            }

        case 14:
            {
                return('O');
                break;
            }

        case 15:
            {
                return('P');
                break;
            }

        case 16:
            {
                return('Q');
                break;
            }

        case 17:
            {
                return('R');
                break;
            }

        case 18:
            {
                return('S');
                break;
            }

        case 19:
            {
                return('T');
                break;
            }

        case 20:
            {
                return('U');
                break;
            }

        case 21:
            {
                return('V');
                break;
            }

        case 22:
            {
                return('W');
                break;
            }

        case 23:
            {
                return('X');
                break;
            }

        case 24:
            {
                return('Y');
                break;
            }

        case 25:
            {
                return('Z');
                break;
            }

        case 26:
            {
                return('-');
                break;
            }

        case 27:
            {
                return('.');
                break;
            }

        case 28:
            {
                return('/');
                break;
            }

        case 29:
            {
                return('/rr');
                break;
            }

        case 30:
            {
                return('(');
                break;
            }

        case 31:
            {
                return(')');
                break;
            }
    }
}

function convertNumberToCharacterNumber($number)
{
    switch($number)
    {
        case 0:
            {
                return('0');
                break;
            }

        case 1:
            {
                return('1');
                break;
            }

        case 2:
            {
                return('2');
                break;
            }

        case 3:
            {
                return('3');
                break;
            }

        case 4:
            {
                return('4');
                break;
            }

        case 5:
            {
                return('5');
                break;
            }

        case 6:
            {
                return('6');
                break;
            }

        case 7:
            {
                return('7');
                break;
            }
    }
}

// Variables d'accès
$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";

// Connexion à la base de donnée
$connect = mysqli_connect($host,$user,$passwd, $bdd) or die("Impossible de se connecter à la base de données.");

// Récupère les valeurs
$ID=$_POST['slot_ID'];
$IDp="0";
$TS=$_POST['slot_TS'];
$DT=$_POST['slot_DT'];
$D1=$_POST['slot_D1'];
$D2=$_POST['slot_D2'];
$D3=$_POST['slot_D3'];

// Insertion du message
$requete = "INSERT INTO Message (ID,IDp,TS,DT,D1,D2,D3,Source) VALUES (".$ID.",".$IDp.",".$TS.",".$DT.",".$D1.",".$D2.",".$D3.",'SigFox');";
$result = mysqli_query($connect,$requete);
mysqli_free_result($result);

// Mise a jour du statut de la station
$requete1 = "UPDATE Station SET Station.statut = 1 WHERE Station.id_station = ".$ID.";";
$result1 = mysqli_query($connect,$requete1);
mysqli_free_result($result1);


switch($DT)
{
        // Type de donnée 0x0001
    case 1: 
        {
            $D1 = ($D1 / 10) - 40;

            $requete2 = "INSERT INTO Mesure (id_station,id_passerelle,type_mesure,valeur) VALUES (".$ID.",".$IDp.",'Temperature',".$D1."),(".$ID.",".$IDp.",'Humidite',".$D2."),(".$ID.",".$IDp.",'Precipitation',".$D3.");";
            $result2 = mysqli_query($connect,$requete2);
            mysqli_free_result($result2);

            break;
        }

        // Type de donnée 0x00FF
    case 255:
        {
            $one = convertNumberToCharacter(((int)$D1 >> 11) & 0x1F);
            $two = convertNumberToCharacter(($D1 >> 6) & 0x1F);
            $three = convertNumberToCharacter(($D1 >> 1) & 0x1F);
            $four = convertNumberToCharacter(((int)(($D1 & (int)0x01) << 4)) | ((int)(($D2 >> 12) & (int)0x0F)));
            $five = convertNumberToCharacter(($D2 >> 7) & 0x1F);
            $six = convertNumberToCharacter(($D2 >> 2) & 0x1F);
            $seven = convertNumberToCharacter(((int)(($D2 & (int)0x03) << 3)) | ((int)(($D3 >> 13) & (int)0x07)));
            $eight = convertNumberToCharacter(($D3 >> 8) & 0x1F);
            $nine = convertNumberToCharacter(($D3 >> 3) & 0x07);
            $ten = convertNumberToCharacterNumber(($D3) & 0x07);

            $stationName =  $one . $two . $three . $four . $five . $six . $seven . $eight . $nine . $ten;

            // Mise a jour du nom de la station
            $requete3 = "UPDATE Station SET Station.nom_station = '".$stationName."' WHERE Station.id_station = ".$ID.";";
            $result3 = mysqli_query($connect,$requete3);
            mysqli_free_result($result3);

            break;
        }

        // Type de donnée inconnu
    default:
        {
            echo("Type de donnees inconnu !");
        }
}
?>
