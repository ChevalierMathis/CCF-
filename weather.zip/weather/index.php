<!DOCTYPE html>

<?php
// Déclaration des paramètres de connexion
$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";

// Connexion au serveur
$connect = mysqli_connect($host,$user,$passwd) or die("erreur de connexion au serveur");

mysqli_select_db($connect, $bdd) or die("erreur de connexion a la base de donnees");

?>


<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Accueil</title>
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
		<link rel="icon" href="/favicon.ico" type="image/x-icon">

		<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">

		<script src="js/modernizr.custom.js"></script>



		<link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.1/dist/leaflet.css"
      integrity="sha512-Rksm5RenBEKSKFjgI3a41vrjkw4EVPlJ3+OiI65vTjIdo9brlAacEuKOiQ5OFh7cOI1bkDwLqdLw3Zg0cRJAAQ=="
      crossorigin=""/>


      <!-- Make sure you put this AFTER Leaflet's CSS -->
		<script src="https://unpkg.com/leaflet@1.3.1/dist/leaflet.js"
		 integrity="sha512-/Nsx9X4HebavoBvEBuyp3I7od5tA0UzAxs+j83KgC8PU0kgB4XiK4Lfe4y4cgBtaRJQEIFCW+oC506aPT2L1zw=="
		 crossorigin=""></script>


		 <style>
		 @media (min-width: 700px)/*pour les grands écrans*/ {
			 .container {
			 margin-right: 14%;
			 margin-left: 14%;
			 margin-top: 20px;
    	 box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			 border-radius: 6px;
			 background-color: white;
			 }
		 }

		 @media (max-width:700px)/*pour les petits écrans*/ {
			 .container {
			 margin-right: 10px;
			 margin-left: 10px;
			 margin-top: 20px;
			 box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			 border-radius: 6px;
			 background-color: white;
			 }
		 }

		 body {
			 background-color: #f4f4f4;
		 }

		 figcaption {
			 box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		 }

		 /* Boutons */
		 .myBtn {
			 display: block;
			 position: fixed;
			 bottom: 10px;
			 right: 10px;
			 z-index: 1000;
			 font-size: 18px;
			 border: none;
			 outline: none;
			 background: url("assets/img/ICON4.png") no-repeat;
			 background-size:cover;
			 color: white;
			 cursor: pointer;
			 padding: 40px 40px;
			 transition: padding 0.2s;
		 }

		 .myBtn2 {
			 display: block;
			 position: fixed;
			 bottom: 10px;
			 left: 10px;
			 z-index: 1000;
			 font-size: 18px;
			 border: none;
			 outline: none;
			 background: url("assets/img/ICON2.png") no-repeat;
			 background-size:cover;
			 color: white;
			 cursor: pointer;
			 padding: 40px 40px;
		 }

		 .myBtn6 {
			 display: block;
			 position: fixed;
			 bottom: 10px;
			 right: 10px;
			 z-index: 998;
			 font-size: 18px;
			 border: none;
			 outline: none;
			 background: url("assets/img/ICON6.png") no-repeat;
			 background-size:cover;
			 color: white;
			 cursor: pointer;
			 padding: 40px 40px;
			 transition: margin 0.2s;
		 }


		 .myBtn5 {
			 display: block;
			 position: fixed;
			 bottom: 10px;
			 right: 10px;
			 z-index: 997;
			 font-size: 18px;
			 border: none;
			 outline: none;
			 background: url("assets/img/ICON5.png") no-repeat;
			 background-size:cover;
			 color: white;
			 cursor: pointer;
			 padding: 40px 40px;
			 transition: margin 0.2s;
		 }



		 .myBtn7 {
			 display: block;
			 position: fixed;
			 bottom: 10px;
			 right: 10px;
			 z-index: 998;
			 font-size: 18px;
			 border: none;
			 outline: none;
			 background: url("assets/img/ICON7.png") no-repeat;
			 background-size:cover;
			 color: white;
			 cursor: pointer;
			 padding: 40px 40px;
			 transition: margin 0.2s;
		 }

			/* Lignes */

		  div.Ligne {
			    position: relative;
			    z-index: 1;

			}

			div.Ligne:before {
				        border-top: 2px solid #72b348;
				        content:"";
				        margin: 0 auto; /* this centers the line to the full width specified */
				        position: absolute; /* positioning must be absolute here, and relative positioning must be applied to the parent */
				        top: 50%; left: 0; right: 0; bottom: 0;
				        width: 95%;
				        z-index: -1;
			}

		  span {
		      /* to hide the lines from behind the text, you have to set the background color the same as the container */
		      background: #fff;
		      padding: 0 15px;
		  }

			div.Ligne2 {
 			    position: relative;
 			    z-index: 1;

	    }

			div.Ligne2:before {
 			        border-top: 2px solid #e10500;
 			        content:"";
 			        margin: 0 auto; /* this centers the line to the full width specified */
 			        position: absolute; /* positioning must be absolute here, and relative positioning must be applied to the parent */
 			        top: 50%; left: 0; right: 0; bottom: 0;
 			        width: 95%;
 			        z-index: -1;
 			 }



			div.Ligne3 {
 			    position: relative;
 			    z-index: 1;

 			 }

			div.Ligne3:before {
 			        border-top: 2px solid #01aeef;
 			        content:"";
 			        margin: 0 auto; /* this centers the line to the full width specified */
 			        position: absolute; /* positioning must be absolute here, and relative positioning must be applied to the parent */
 			        top: 50%; left: 0; right: 0; bottom: 0;
 			        width: 95%;
 			        z-index: -1;
 			 }

			 /* Loader */
			 #loader {
			   position: absolute;
			   right: 20px;
			   top: 30px;
			   z-index: 1001;
			   border: 4px solid #f4f4f4;
			   border-radius: 50%;
			   border-top: 4px solid #3498db;
			   border-bottom: 4px solid #3498db;
			   width: 50px;
			   height: 50px;
			   -webkit-animation: spin 1s ease infinite;
			   animation: spin 1s ease infinite;
			 }

			 #loader2 {
			   position: absolute;
			   right: 30px;
			   top: 40px;
			   z-index: 1001;
			   border: 4px solid #f4f4f4;
			   border-radius: 50%;
			   border-top: 4px solid grey;
			   border-bottom: 4px solid grey;
			   width: 30px;
			   height: 30px;
			   -webkit-animation: spin 1s linear infinite;
			   animation: spin 1s linear infinite;
			 }

			 /* Animation du loader (tourne) */
			 @-webkit-keyframes spin {
			   0% { -webkit-transform: rotate(0deg); }
			   100% { -webkit-transform: rotate(360deg); }
			 }

			 @keyframes spin {
			   0% { transform: rotate(0deg); }
			   100% { transform: rotate(360deg); }
			 }

			 /* Animation d'apparition */
			 .animate-bottom {
			   position: relative;
			   -webkit-animation-name: animatebottom;
			   -webkit-animation-duration: 1s;
			   animation-name: animatebottom;
			   animation-duration: 1s
			 }

			 @-webkit-keyframes animatebottom {
			   from { bottom:-100px; opacity:0 }
			   to { bottom:0px; opacity:1 }
			 }

			 @keyframes animatebottom {
			   from{ bottom:-100px; opacity:0 }
			   to{ bottom:0; opacity:1 }
			 }

			 #body /*permet l'animation de chargement*/{
			   filter: brightness(100%);
			   transition: filter 0.5s;
			 }





		 </style>

</head>
<body onload="myFunction()">

		<div id="loader"></div>
		<div id="loader2"></div>

<!-- Corps du site -->
<div id="body" style="background-color: #f4f4f4;">
<div id="title" style="color:#646464;font-weight:bold;font-size: 31px;padding:20px 0px 10px 0px;text-align:center;filter: blur(0px);"><img src="images/Image1.png" style="color:#f36a10;height:45px;vertical-align: bottom;margin-right:10px;">Projet : Collecte de Données Météo Agricoles</div>


		<!-- Tronc 1 du site -->
		<div class="container demo-3 animate-bottom" id="myDiv" style="filter: blur(0px);">
			<ul class="grid cs-style-4">
				<div class="Ligne"><span><img src="assets/img/ICON10.png" style="color:#f36a10;height:22px;vertical-align: initial;margin-right:10px;"><b>En Ligne</b></span></div>

				<!------------------------------------------------------------------------------------------------>
				<!-- Catégorie EN LIGNE -->
	      <!-- Récupération de toutes les stations en ligne et affichage de blocs correpondant à chacune d'elles -->
				<!-- Requêtes SQL de récupérations des dernieres données météo ainsi que la Latitude la Longitude et L'id -->
	      <?php

				$totalMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 1") or die('erreur requete 222');
				$row_cnt = mysqli_num_rows($totalMS);
				mysqli_free_result($totalMS);

				$nombreMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 1") or die('erreur requete 223');
				$i=1;

				while(($row = mysqli_fetch_array($nombreMS)) && ($i<=$row_cnt))
				{ $idStation = $row[0];

					//////////////////////////////////////////////
					$resultTempLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
					$resultHumiLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Humidite") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
					$resultPreciLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Precipitation") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');


					$queryNom = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
					$resultNom = mysqli_query($connect,$queryNom) or die('erreur 4');
					mysqli_free_result($queryNom);

					$queryNom1 = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
					$resultNom1 = mysqli_query($connect,$queryNom1) or die('erreur 4');
					mysqli_free_result($queryNom1);


					$queryCoord = "SELECT Station.latitude, Station.longitude FROM Station WHERE Station.id_station = ".$idStation;
					$resultCoord = mysqli_query($connect,$queryCoord) or die('erreur 6');
					mysqli_free_result($queryCoord);
					//////////////////////////////////////////////

			?>
			<!-- Bloc de Microstation (généré tant qu'il y a des Microstations)-->
			<li>
				<figure style="box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);">
					<div>

						<div style="padding:90px 1px;background-color:white;background-repeat: no-repeat;background-size: cover;text-align:center;font-size:23px;">
							<?php
								$resultNom1 = mysqli_fetch_array($resultNom1);
								echo '<div style="color:#646464;"><b>'.$resultNom1["nom_station"].'</b></div><div style="color:#646464;">Id : '.$idStation.'</div>'; // Affichage code html dans echo en appelant la variable
							?>
						</div>

					</div>
					<figcaption>
						<h3 style="padding-bottom:13px;font-size: 21px;">
							<?php
								$resultNom = mysqli_fetch_array($resultNom);
								echo ''.$resultNom["nom_station"].''; // Affichage code html dans echo en appelant la variable
							?>
						</h3>
					</br>
				<div style="color:#3c4a50;">
					<?php
						$resultTempLastUnique = mysqli_fetch_array($resultTempLastUnique);
						echo '<strong>Température : </strong><span style="float:right;">'.$resultTempLastUnique["valeur"]." °C</span>"; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				<div style="color:#3c4a50;">
					<?php
						$resultHumiLastUnique = mysqli_fetch_array($resultHumiLastUnique);
						echo '<strong>Humidité :</strong> <span style="float:right;"> '.$resultHumiLastUnique["valeur"].' %</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				<div style="color:#3c4a50;">
					<?php
						$resultPreciLastUnique = mysqli_fetch_array($resultPreciLastUnique);
						echo '<strong>Précipitation :</strong> <span style="float:right;"> '.$resultPreciLastUnique["valeur"].' mm</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				</br>
				<div>
					<?php
						$resultCoord = mysqli_fetch_array($resultCoord);
						$resultSerie = mysqli_fetch_array($resultSerie);
						echo '<strong>Latitude : </strong><span style="float:right;">'.$resultCoord["latitude"].'</span></br><strong>Longitude :</strong><span style="float:right;">'.$resultCoord["longitude"]."</span></br><strong>Identification :</strong><span style='float:right;'>".$idStation.'</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
						<a onclick="location.href='indexMicroStation.php?idStation=<?php printf("%d",$row[0]);?>';" style="cursor: pointer;">Voir</a>
					</figcaption>
				</figure>
			</li>

			<?php
				$i=$i++;
				mysqli_free_result($resultNom);
				mysqli_free_result($resultStatut);
				mysqli_free_result($resultCoord);
				mysqli_free_result($resultDateF);
				mysqli_free_result($idStation);
					}
			?>
			<!------------------------------------------------------------------------------------------------>


</ul>
</div>
<div class="container demo-3 animate-bottom" id="myDiv2" style="filter: blur(0px);">
<ul class="grid cs-style-4">


<div class="Ligne Ligne2"><span><img src="assets/img/ICON11.png" style="color:#f36a10;height:22px;vertical-align: initial;margin-right:10px;"><b>Hors Ligne</b></span></div>


			<!------------------------------------------------------------------------------------------------>
			<!-- Catégorie EN LIGNE -->
			<!-- Récupération de toutes les stations en ligne et affichage de blocs correpondant à chacune d'elles -->
			<!-- Requêtes SQL de récupérations des dernieres données météo ainsi que la Latitude la Longitude et L'id -->
			<?php
				$totalMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 0") or die('erreur requete 222');
				$row_cnt = mysqli_num_rows($totalMS);
				mysqli_free_result($totalMS);

				$nombreMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 0") or die('erreur requete 223');
				$i=1;

				while(($row = mysqli_fetch_array($nombreMS)) && ($i<=$row_cnt))
				{ $idStation = $row[0];

					//////////////////////////////////////////////
					$resultTempLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
					$resultHumiLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Humidite") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
					$resultPreciLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Precipitation") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');


					$queryNom = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
					$resultNom = mysqli_query($connect,$queryNom) or die('erreur 4');
					mysqli_free_result($queryNom);

					$queryNom1 = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
					$resultNom1 = mysqli_query($connect,$queryNom1) or die('erreur 4');
					mysqli_free_result($queryNom1);


					$queryCoord = "SELECT Station.latitude, Station.longitude FROM Station WHERE Station.id_station = ".$idStation;
					$resultCoord = mysqli_query($connect,$queryCoord) or die('erreur 6');
					mysqli_free_result($queryCoord);


					//////////////////////////////////////////////
			?>
			<!-- Bloc de Microstation (généré tant qu'il y a des Microstations)-->
			<li>
				<figure style="box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);">
					<div>

						<div style="padding:90px 1px;background-color:white;background-repeat: no-repeat;background-size: cover;text-align:center;font-size:23px;">
							<?php
								$resultNom1 = mysqli_fetch_array($resultNom1);
								echo '<div style="color:#646464;"><b>'.$resultNom1["nom_station"].'</b></div><div style="color:#646464;">Id : '.$idStation.'</div>'; // Affichage code html dans echo en appelant la variable
							?>
						</div>

					</div>
					<figcaption>
						<h3 style="padding-bottom:13px;font-size: 21px;">
							<?php
								$resultNom = mysqli_fetch_array($resultNom);
								echo ''.$resultNom["nom_station"].''; // Affichage code html dans echo en appelant la variable
							?>
						</h3>
					</br>
				<div style="color:#3c4a50;">
					<?php
						$resultTempLastUnique = mysqli_fetch_array($resultTempLastUnique);
						echo '<strong>Température : </strong><span style="float:right;">'.$resultTempLastUnique["valeur"]." °C</span>"; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				<div style="color:#3c4a50;">
					<?php
						$resultHumiLastUnique = mysqli_fetch_array($resultHumiLastUnique);
						echo '<strong>Humidité :</strong> <span style="float:right;"> '.$resultHumiLastUnique["valeur"].' %</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				<div style="color:#3c4a50;">
					<?php
						$resultPreciLastUnique = mysqli_fetch_array($resultPreciLastUnique);
						echo '<strong>Précipitation :</strong> <span style="float:right;"> '.$resultPreciLastUnique["valeur"].' mm</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				</br>
				<div>
					<?php
						$resultCoord = mysqli_fetch_array($resultCoord);
						$resultSerie = mysqli_fetch_array($resultSerie);
						echo '<strong>Latitude : </strong><span style="float:right;">'.$resultCoord["latitude"].'</span></br><strong>Longitude :</strong><span style="float:right;">'.$resultCoord["longitude"]."</span></br><strong>Identification :</strong><span style='float:right;'>".$idStation.'</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
						<a onclick="location.href='indexMicroStation.php?idStation=<?php printf("%d",$row[0]);?>';" style="cursor: pointer;">Voir</a>
					</figcaption>
				</figure>
			</li>

			<?php
				$i=$i++;
				mysqli_free_result($resultNom);
				mysqli_free_result($resultStatut);
				mysqli_free_result($resultCoord);
				mysqli_free_result($resultDateF);
				mysqli_free_result($idStation);
					}
			?>
			<!------------------------------------------------------------------------------------------------>


</ul>
</div>
<div class="container demo-3 animate-bottom" id="myDiv3" style="filter: blur(0px);">
<ul class="grid cs-style-4">

<div class="Ligne Ligne3"><span><img src="assets/img/ICON12.png" style="color:#f36a10;height:22px;vertical-align: initial;margin-right:10px;"><b>Carte des Micro-Stations</b></span></div>

<!------------------------------------------------------------------------------------------------>
<!-- Affichage de la carte -->
<div id="mapid" style="position:sticky;"></div>

<script>
	var mymap = L.map('mapid').setView([43, 1.29], 7);

	/* Marker -> repères sur la carte
	Récupération de toutes les stations en ligne et affichage des marqueurs
	Requêtes SQL de récupérations de la Latitude la Longitude le Nom et L'id */
	<?php
		$totalMS1 = mysqli_query($connect, "SELECT * FROM Station") or die('erreur requete 222');
		$row_cnt1 = mysqli_num_rows($totalMS1);
		mysqli_free_result($totalMS1);

		$nombreMS1 = mysqli_query($connect, "SELECT id_station FROM Station") or die('erreur requete 223');
		$a=1;

		while(($row = mysqli_fetch_array($nombreMS1)) && ($a<=$row_cnt1))
		{	$idStation1 = $row[0];

			$queryCoord11 = "SELECT Station.latitude FROM Station WHERE Station.id_station = ".$idStation1;
			$queryCoord12 = "SELECT Station.longitude FROM Station WHERE Station.id_station = ".$idStation1;
			$queryNom3 = "SELECT nom_station FROM `Station` WHERE id_station = ".$idStation1;

			$resultCoord11 = mysqli_query($connect,$queryCoord11) or die('erreur 611');
			$resultCoord12 = mysqli_query($connect,$queryCoord12) or die('erreur 612');
			$resultNom3 = mysqli_query($connect,$queryNom3) or die('erreur 613');
			//$resultNom3 = mysqli_fetch_array($resultNom3);

			mysqli_free_result($queryCoord11);
			mysqli_free_result($queryCoord12);
			mysqli_free_result($queryNom3);

			$Lat = mysqli_fetch_assoc($resultCoord11);
			$Long = mysqli_fetch_assoc($resultCoord12);
			$RowName = mysqli_fetch_assoc($resultNom3);
	?>
	/* Génération du repère sur la carte */
	var Lat = <?php echo $Lat['latitude']; ?>;
	var Long = <?php echo $Long['longitude']; ?>;
	var Id = <?php echo $idStation1; ?>;
	var Name = '<b>' + '<?php echo(''.$RowName["nom_station"].'') ?>' + '</b>';

	var marker = L.marker([Lat, Long]).addTo(mymap).bindPopup(Name + '</br> Id :' + Id).openPopup();

	<?php
		$a=$a++;
		}
	?>

		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
				attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
				maxZoom: 18,
				id: 'mapbox.streets',
				accessToken: 'pk.eyJ1IjoiY2xlbWVudGhlcm5hbmRleiIsImEiOiJjamk1eTEycG4wbW44M3FwZnpmYW1naDRuIn0.Cn6ph_v_M3w2FwnLxRQQkQ'
		}).addTo(mymap);
</script>
<!------------------------------------------------------------------------------------------------>


</ul>
</div>
</div>
		<!--boutons de navigatiion gauche-->
    <button onclick="location.href='https://btslimayrac.ovh/';" class="myBtn2"></button>

		<!--boutons de navigatiion droit-->
		<button onclick="var btns=document.getElementsByClassName('active'); /*Permet le dépliement des boutons lors du click*/

		if(btns.length==0) /*Si les boutons ne sont pas dépliés, alors :*/ {

				/*dépliement*/
		 		document.getElementById('btn1').style.margin = '0px 0px 100px 0px';
		    document.getElementById('btn1').classList.add('active');
		    document.getElementById('btn2').style.margin = '0px 0px 200px 0px';
		    document.getElementById('btn2').classList.add('active');
				document.getElementById('btn3').style.margin = '0px 0px 300px 0px';
				document.getElementById('btn3').classList.add('active');

				document.getElementById('tooltip1').style.display = 'block';
				document.getElementById('tooltip2').style.display = 'block';
				document.getElementById('tooltip3').style.display = 'block';

				/*tooltips apparition*/
				document.getElementById('tooltip1').style.color = '#646464';
				document.getElementById('tooltip2').style.color = '#646464';
				document.getElementById('tooltip3').style.color = '#646464';

				/*luminosité du fond plus sombre*/
				document.getElementById('body').style.filter = 'brightness(70%)';

		}

		else /*Si les boutons sont dépliés, alors on les range :*/ {

				/*repliement*/
		    document.getElementById('btn1').style.margin = '0px 0px 0px 0px';
		    document.getElementById('btn1').classList.remove('active');
		    document.getElementById('btn2').style.margin = '0px 0px 0px 0px';
		    document.getElementById('btn2').classList.remove('active');
				document.getElementById('btn3').style.margin = '0px 0px 0px 0px';
				document.getElementById('btn3').classList.remove('active');

				/*tooltips transparents*/
				document.getElementById('tooltip1').style.display = 'none';
				document.getElementById('tooltip2').style.display = 'none';
				document.getElementById('tooltip3').style.display = 'none';

				/*disparition des tooltips*/
				document.getElementById('tooltip1').style.color = 'transparent';
				document.getElementById('tooltip2').style.color = 'transparent';
				document.getElementById('tooltip3').style.color = 'transparent';

				/*luminosité du fond normale*/
				document.getElementById('body').style.filter = 'brightness(100%)';}" class="myBtn" ></button>

						<!--boutons de navigatiion (dépliants)-->
				    <button id="btn1" onclick="location.href='/formulaire/Messages.php';" class="myBtn5"><div id="tooltip1" style="color = transparent;position:absolute;font-size: 18px;margin-left: -192px;margin-top: -23px;display: none;/*transition: color 1s*/;background-color: white; border-radius: 50px;padding: 10px;box-shadow: 0px 10px 13px -5px rgba(80,80,80,1);">Messages reçus</div></button>
						<button id="btn2" onclick="location.href='/formulaire/formulaireAjoutMS.html';" class="myBtn6"><div id="tooltip2" style="color = transparent;position:absolute;font-size: 18px;margin-left: -266px;margin-top: -23px;display: none;/*transition: color 1s*/;background-color: white; border-radius: 50px;padding: 10px;box-shadow: 0px 10px 13px -5px rgba(80,80,80,1);">Ajouter une Microstation</div></button>
						<button id="btn3" onclick="location.href='/formulaire/formulaireSuppressionMS.php';" class="myBtn7"><div id="tooltip3" style="color = transparent;position:absolute;font-size: 18px;margin-left: -289px;margin-top: -23px;display: none;/*transition: color 1s*/;background-color: white; border-radius: 50px;padding: 10px;box-shadow: 0px 10px 13px -5px rgba(80,80,80,1);">Supprimer une Microstation</div></button>

	</br>
	</br>
		<script src="js/toucheffects.js"></script>
		<script> //pour le loader
    var myVar;

    function myFunction() {
        myVar = setTimeout(showPage, 500); //temps en ([secondes]000)
    }

    function showPage() {
      document.getElementById("loader").style.display = "none";
			document.getElementById("loader2").style.display = "none";
      document.getElementById("myDiv").style.display = "block";
      document.getElementById("myDiv2").style.display = "block";
			document.getElementById("myDiv3").style.display = "block";
    }
    </script>
	</body>
</html>
