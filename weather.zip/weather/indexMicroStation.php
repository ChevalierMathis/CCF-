<!DOCTYPE html>
<?php

$idStation = $_GET["idStation"];
// Déclaration des paramètres de connexion
$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";


// Connexion au serveur
$connect = mysqli_connect($host,$user,$passwd) or die("erreur de connexion au serveur");

mysqli_select_db($connect, $bdd) or die("erreur de connexion a la base de donnees");



/////////////////////////////////// Creation des requetes ///////////////////////////////////


//Dernière donnée enregistrée (par type de mesure)
$resultTempLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur requete 1');
$resultHumiLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Humidite") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur requete 2');
$resultPreciLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Precipitation") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur requete 3');

//Dernière précipitation pour changer l'icone de météo
$resultPreciLastUnique1 = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Precipitation") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur requete 4');

//Historiques des valeurs par date, en fonction de leur type de données
$histoTemp = mysqli_query($connect, 'SELECT * FROM Mesure WHERE Mesure.type_mesure = "Temperature" AND Mesure.id_station = '.$idStation.' ORDER BY Mesure.date_heure DESC') or die('erreur requete 5');
$histoHumi = mysqli_query($connect, 'SELECT * FROM Mesure WHERE Mesure.type_mesure = "Humidite" AND Mesure.id_station = '.$idStation.' ORDER BY Mesure.date_heure DESC') or die('erreur requete 6');
$histoPreci = mysqli_query($connect, 'SELECT * FROM Mesure WHERE Mesure.type_mesure = "Precipitation" AND Mesure.id_station = '.$idStation.' ORDER BY Mesure.date_heure DESC') or die('erreur requete 7');

//12 dernières valeurs [Températures et DateHeure]
$resultTemp1 = mysqli_query($connect,
'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Temperature")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur requete 8');

$resultTemp2 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Temperature")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur requete 9');

$resultTemp3 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Temperature")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur requete 10');

$resultTemp4 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Temperature")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur requete 11');

//12 dernières valeurs [Humidité et DateHeure]
$resultHumi1 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Humidite")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur requete 12');

$resultHumi2 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Humidite")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur requete 13');

$resultHumi3 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Humidite")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur requete 14');

//12 dernières valeurs [Précipitations et DateHeure]
$resultPreci1 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Precipitation")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,16) AS t
ORDER BY t.date_heure ASC LIMIT 0,16;') or die('erreur requete 15');

$resultPreci2 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Precipitation")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,16) AS t
ORDER BY t.date_heure ASC LIMIT 0,16;') or die('erreur requete 16');

$resultPreci3 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM Mesure, Station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Precipitation")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur requete 17');

//Informations sur la Micro-Station
$queryNom = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
$resultNom1 = mysqli_query($connect,$queryNom) or die('erreur requete 18-1');

$resultNom2 = mysqli_query($connect,$queryNom) or die('erreur requete 18-2');

$resultNom3 = mysqli_query($connect,$queryNom) or die('erreur requete 18-3');

$resultNom4 = mysqli_query($connect,$queryNom) or die('erreur requete 18-4');

$resultNom5 = mysqli_query($connect,$queryNom) or die('erreur requete 18-5');

$queryStatut = "SELECT Station.statut FROM Station WHERE Station.id_station = ".$idStation;
$resultStatut = mysqli_query($connect,$queryStatut) or die('erreur requete 19');

$queryCoord = "SELECT Station.latitude, Station.longitude FROM Station WHERE Station.id_station = ".$idStation;
$resultCoord = mysqli_query($connect,$queryCoord) or die('erreur requete 20');

$queryRegion = "SELECT Station.region FROM Station WHERE Station.id_station = ".$idStation;
$resultRegion = mysqli_query($connect,$queryRegion) or die('erreur requete 21');

$queryDept = "SELECT Station.departement FROM Station WHERE Station.id_station = ".$idStation;
$resultDept = mysqli_query($connect,$queryDept) or die('erreur requete 22');

$queryDateF = "SELECT Station.date_fabrication FROM Station WHERE Station.id_station = ".$idStation;
$resultDateF = mysqli_query($connect,$queryDateF) or die('erreur requete 24');


//Requêtes de l'ancien site


$queryminiHumi = 'SELECT MIN(valeur)
        FROM Mesure, Station
        WHERE Mesure.id_station = Station.id_station
        AND (Station.id_station = '.$idStation.')
        AND Mesure.type_mesure = "Humidite"
    	AND (DATE(Mesure.date_heure) = CURRENT_DATE())';
$miniHumi = mysqli_query($connect,$queryminiHumi) or die('erreur requete 25');

$querymaxiiHumi = 'SELECT MAX(valeur)
        FROM Mesure, Station
        WHERE Mesure.id_station = Station.id_station
        AND (Station.id_station = '.$idStation.')
        AND Mesure.type_mesure = "Humidite"
    	AND (DATE(Mesure.date_heure) = CURRENT_DATE())';
$maxiHumi = mysqli_query($connect,$querymaxiiHumi) or die('erreur requete 26');

$querymoyenneiHumi = 'SELECT AVG(valeur)
        FROM Mesure, Station
        WHERE Mesure.id_station = Station.id_station
        AND (Station.id_station = '.$idStation.')
        AND Mesure.type_mesure = "Humidite"
    	AND (DATE(Mesure.date_heure) = CURRENT_DATE())';
$moyenneHumi = mysqli_query($connect,$querymoyenneiHumi) or die('erreur requete 27');



$queryminiTemp = 'SELECT MIN(valeur)
        FROM Mesure, Station
        WHERE Mesure.id_station = Station.id_station
        AND (Station.id_station = '.$idStation.')
        AND Mesure.type_mesure = "Temperature"
    	AND (DATE(Mesure.date_heure) = CURRENT_DATE())';
$miniTemp = mysqli_query($connect,$queryminiTemp) or die('erreur requete 25');

$querymaxiiTemp = 'SELECT MAX(valeur)
        FROM Mesure, Station
        WHERE Mesure.id_station = Station.id_station
        AND (Station.id_station = '.$idStation.')
        AND Mesure.type_mesure = "Temperature"
    	AND (DATE(Mesure.date_heure) = CURRENT_DATE())';
$maxiTemp = mysqli_query($connect,$querymaxiiTemp) or die('erreur requete 26');

$querymoyenneiTemp = 'SELECT AVG(valeur)
        FROM Mesure, Station
        WHERE Mesure.id_station = Station.id_station
        AND (Station.id_station = '.$idStation.')
        AND Mesure.type_mesure = "Temperature"
    	AND (DATE(Mesure.date_heure) = CURRENT_DATE())';
$moyenneTemp = mysqli_query($connect,$querymoyenneiTemp) or die('erreur requete 27');



$queryminiPreci = 'SELECT date_heure
            FROM Mesure, Station
            WHERE (Mesure.id_station = Station.id_station)
            AND (Station.id_station = '.$idStation.')
            AND (Mesure.type_mesure = "Precipitation")
            AND ((Mesure.valeur >= 1))
        ORDER BY date_heure  DESC LIMIT 0,1;';
$miniPreci = mysqli_query($connect,$queryminiPreci) or die('erreur requete 25');


/*
  $resultTemp7 = mysqli_query($connect, 'SELECT Mesure.valeur, date_heure FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,12;') or die('erreur 1');
  $resultTemp8 = mysqli_query($connect, 'SELECT Mesure.valeur, date_heure FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,12;') or die('erreur 1');

  $queryHumi = "SELECT Mesure.valeur FROM Mesure WHERE Mesure.type_mesure = 'Humidite' AND Mesure.id_station = ".$idStation." ORDER BY id_mesure DESC LIMIT 0,1";
  $resultHumi = mysqli_query($connect,$queryHumi) or die('erreur 2');

  $queryPreci = "SELECT Mesure.valeur FROM Mesure WHERE Mesure.type_mesure = 'Precipitation' AND Mesure.id_station = ".$idStation." ORDER BY id_mesure DESC LIMIT 0,1";
  $resultPreci = mysqli_query($connect,$queryPreci) or die('erreur 3');

*/

//Toutes les données
$Tout = mysqli_query($connect, 'SELECT * FROM `Message` WHERE (Message.ID = '.$idStation.') ORDER BY DT_serveur DESC;') or die('erreur requete 1');

?>


<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Micro-Station</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
		<link rel="icon" href="/favicon.ico" type="image/x-icon">

    <!-- css du bouton de navigation -->
    <link rel="stylesheet" type="text/css" href="assets/css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="assets/css/demo.css" />
		<link rel="stylesheet" type="text/css" href="assets/css/component.css" />


    <!-- script au debut pour éviter des bugs  d'affichage -->
    <script src="assets/js/modernizr.min.js"></script>

    <link rel="stylesheet" href="datatables/jquery.dataTables.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Bootstrap et css du site -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <style>

		div.col-md-12 {
		  width: 100%;
		  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);
		  text-align: center;
		  margin-bottom: 10px;
		  padding: 0px;
		}

		div.head {
			color:  white;
			padding: 10px;
			font-size: 40px;
		}

		div.littlebox {
			padding: 10px;
		}

		div.littlebox2 {
			padding: 10px;
		}

		/* Boutons */
		.myBtn {
		  display: block;
		  position: fixed;
		  bottom: 10px;
		  right: 10px;
		  z-index: 999;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background: url("assets/img/ICON1.png") no-repeat;
		  background-size:cover;
		  color: white;
		  cursor: pointer;
		  padding: 40px 40px;
		  transition: margin 0.2s;
		}

		.myBtn2 {
		  display: block;
		  position: fixed;
		  bottom: 10px;
		  left: 10px;
		  z-index: 999;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background: url("assets/img/ICON2.png") no-repeat;
		  background-size:cover;
		  color: white;
		  cursor: pointer;
		  padding: 40px 40px;
		  transition: margin 0.2s;
		}

		.myBtn7 {
		  display: block;
		  position: fixed;
		  bottom: 10px;
		  right: 10px;
		  z-index: 998;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background: url("assets/img/ICON7.png") no-repeat;
		  background-size:cover;
		  color: white;
		  cursor: pointer;
		  padding: 40px 40px;
		  transition: margin 0.2s;
		}


		.myBtn8 {
		  display: block;
		  position: fixed;
		  bottom: 10px;
		  right: 10px;
		  z-index: 997;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background: url("assets/img/ICON8.png") no-repeat;
		  background-size:cover;
		  color: white;
		  cursor: pointer;
		  padding: 40px 40px;
		  transition: margin 0.2s;
		}

		.myBtn4 {
		  display: block;
		  position: fixed;
		  bottom: 10px;
		  right: 10px;
		  z-index: 1000;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background: url("assets/img/ICON4.png") no-repeat;
		  background-size:cover;
		  color: white;
		  cursor: pointer;
		  padding: 40px 40px;
		  transition: padding 0.2s;
		}

		/* Loader 1 */
		#loader {
		  position: absolute;
		  right: 20px;
		  top: 30px;
		  z-index: 1001;
		  border: 4px solid #f4f4f4;
		  border-radius: 50%;
		  border-top: 4px solid #3498db;
		  border-bottom: 4px solid #3498db;
		  width: 50px;
		  height: 50px;
		  -webkit-animation: spin 1s ease infinite;
		  animation: spin 1s ease infinite;
		}

		/* Loader 2 */
		#loader2 {
		  position: absolute;
		  right: 30px;
		  top: 40px;
		  z-index: 1001;
		  border: 4px solid #f4f4f4;
		  border-radius: 50%;
		  border-top: 4px solid grey;
		  border-bottom: 4px solid grey;
		  width: 30px;
		  height: 30px;
		  -webkit-animation: spin 1s linear infinite;
		  animation: spin 1s linear infinite;
		}

		/* Animation du loader (tourne) */
		@-webkit-keyframes spin {
		  0% { -webkit-transform: rotate(0deg); }
		  100% { -webkit-transform: rotate(360deg); }
		}

		@keyframes spin {
		  0% { transform: rotate(0deg); }
		  100% { transform: rotate(360deg); }
		}

		/* Animation d'apparition */
		.animate-bottom {
		  position: relative;
		  -webkit-animation-name: animatebottom;
		  -webkit-animation-duration: 1s;
		  animation-name: animatebottom;
		  animation-duration: 1s
		}

		@-webkit-keyframes animatebottom {
		  from { bottom:-100px; opacity:0 }
		  to { bottom:0px; opacity:1 }
		}

		@keyframes animatebottom {
		  from{ bottom:-100px; opacity:0 }
		  to{ bottom:0; opacity:1 }
		}

		#myDiv /*tronc 1 - permet l'animation de chargement*/{
		  display: none;
		}

		#myDiv2 /*tronc 2 - permet l'animation de chargement*/ {
		  display: none;
		}

		#body {
		  filter: brightness(100%);
		  transition: filter 0.5s;
		}



		@media (min-width: 1040px)/*pour les grands écrans*/ {
			.container-fluid {
				padding-right: 14%;
				padding-left: 14%;
				margin-right: auto;
				margin-left: auto;
			}
		}

		@media (max-width:1040px)/*pour les petits écrans*/ {
			.container-fluid {
				padding-right: 15px;
				padding-left: 15px;
				margin-right: auto;
				margin-left: auto;
			}

			.jumbotron {
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			}

		}

    </style>

	</head>
	<body onload="myFunction()">

    <div id="loader"></div>
    <div id="loader2"></div>

    <!--boutons de navigatiion gauche-->
    <button onclick="location.href='index.php';" class="myBtn2"></button>

    <!--boutons de navigatiion droit-->
    <button onclick="var btns=document.getElementsByClassName('activated'); /*Permet le dépliement des boutons lors du click*/
		if(btns.length==0) /*Si les boutons ne sont pas dépliés, alors :*/ {

      /*dépliement*/
			document.getElementById('btn1').style.margin = '0px 0px 100px 0px';
			document.getElementById('btn1').classList.add('activated');
			document.getElementById('btn2').style.margin = '0px 0px 300px 0px';
			document.getElementById('btn2').classList.add('activated');
			document.getElementById('btn3').style.margin = '0px 0px 200px 0px';
			document.getElementById('btn3').classList.add('activated');

			document.getElementById('tooltip1').style.color = '#646464';
			document.getElementById('tooltip2').style.color = '#646464';
			document.getElementById('tooltip3').style.color = '#646464';

      /*tooltips apparition*/
			document.getElementById('tooltip1').style.display = 'block';
			document.getElementById('tooltip2').style.display = 'block';
			document.getElementById('tooltip3').style.display = 'block';

      /*luminosité du fond plus sombre*/
			document.getElementById('body').style.filter = 'brightness(70%)';
		}

		else /*Si les boutons sont dépliés, alors on les range :*/ {

      /*repliement*/
			document.getElementById('btn1').style.margin = '0px 0px 0px 0px';
			document.getElementById('btn1').classList.remove('activated');
			document.getElementById('btn2').style.margin = '0px 0px 0px 0px';
			document.getElementById('btn2').classList.remove('activated');
			document.getElementById('btn3').style.margin = '0px 0px 0px 0px';
			document.getElementById('btn3').classList.remove('activated');

      /*tooltips transparents*/
			document.getElementById('tooltip1').style.color = 'transparent';
			document.getElementById('tooltip2').style.color = 'transparent';
			document.getElementById('tooltip3').style.color = 'transparent';

      /*disparition des tooltips*/
			document.getElementById('tooltip1').style.display = 'none';
			document.getElementById('tooltip2').style.display = 'none';
			document.getElementById('tooltip3').style.display = 'none';

      /*luminosité du fond normale*/
			document.getElementById('body').style.filter = 'brightness(100%)';}" class="myBtn4" ></button>

    <!--boutons de navigatiion (dépliants)-->
    <button id="btn1" class="myBtn" data-toggle="modal" data-target="#exampleModal"><div id="tooltip1" style="color = transparent;position: absolute;font-size: 18px; margin-left: -260px;margin-top: -23px;display: none;/*transition: color 1s*/;background-color: white; border-radius: 50px;padding: 10px;box-shadow: 0px 10px 13px -5px rgba(80,80,80,1);">Choix de la Microstation</div></button>
		<button id="btn2" onclick="location.href='/formulaire/formulaireSuppressionMS.php';" class="myBtn7"><div id="tooltip3" style="color = transparent;position:absolute;font-size: 18px;margin-left: -289px;margin-top: -23px;display: none;/*transition: color 1s*/;background-color: white; border-radius: 50px;padding: 10px;box-shadow: 0px 10px 13px -5px rgba(80,80,80,1);">Supprimer une Microstation</div></button>
		<button id="btn3" onclick="location.href='/formulaire/formulaireModifierMS.php?idStation=<?php printf("%d",$idStation);?>';" class="myBtn8"><div id="tooltip2" style="color = transparent;position:absolute;font-size: 18px;margin-left: -274px;margin-top: -23px;display: none;/*transition: color 1s*/;background-color: white; border-radius: 50px;padding: 10px;box-shadow: 0px 10px 13px -5px rgba(80,80,80,1);">Modifier une Microstation</div></button>

<!-- Corps du site -->
<div id="body" style="background-color: #f4f4f4;">
		<div class="container-fluid animate-bottom" id="myDiv">
			<div class="footer-basic" style="padding-bottom:15px;">
					<div class="jumbotron" style="background-color:rgb(255,255,255);margin-top:20px;padding-top:6px;padding-bottom:10px">
							<h1 class="text-center"><!--Nom de la Microstation et affichage de l'icone de météo-->
                <b>
                  <?php
                    $resultNom1 = mysqli_fetch_array($resultNom1);

                    echo ''.$resultNom1["nom_station"].'';
                  ?>
                </b>

                <?php
                $resultPreciLastUnique1 = mysqli_fetch_array($resultPreciLastUnique1);
               if ($resultPreciLastUnique1[0] == 0){
                  echo '<img src="assets/img/1.png" style="height:80px;margin-bottom:5px;">';
                }
                else {
                  echo '<img src="assets/img/2.png" style="height:80px;margin-bottom:5px;">';
                }
                ?>
              </h1>




              <div class="col-md-4"><!--Présentation Températures-->
                <div style="text-align:center;color:#f39c12;font-size:30px;"><b>Température</b></div>
                <div class="col-md-12">
                <div class="card">

                  <div class="head" style="background-color:#f39c12;"> <!--Dernière Températures-->
                    <h1>
                      <?php
          							$resultTempLastUnique = mysqli_fetch_array($resultTempLastUnique);
          							echo '<b>'.$resultTempLastUnique["valeur"]." °C</b>"; // Affichage code html dans echo en appelant la variable
        						  ?>
                    </h1>
                  </div>



                  <div class="col-md-4"> <!--Températures Min-->
                    <div class="littlebox2">
                      <p>Minimum</p>
                      <?php
                        $miniTemp = mysqli_fetch_array($miniTemp);
                        echo '<p><b>'.round($miniTemp["MIN(valeur)"],2)." °C</b></p>"; // Affichage code html dans echo en appelant la variable
                      ?>
                    </div>
                  </div>

                  <div class="col-md-4"> <!--Températures Moy-->
                    <div class="littlebox2">
                      <p>Moyenne</p>
                      <?php
                        $moyenneTemp = mysqli_fetch_array($moyenneTemp);
                        echo '<p><b> '.round($moyenneTemp["AVG(valeur)"],2).' °C</b></p>'; // Affichage code html dans echo en appelant la variable
                      ?>
                    </div>
                  </div>

                  <div class="col-md-4"><!--Températures Max-->
                    <div class="littlebox2">
                      <p>Maximum</p>
                      <?php
                        $maxiTemp = mysqli_fetch_array($maxiTemp);
                        echo '<p><b> '.round($maxiTemp["MAX(valeur)"],2).' °C</b></p>'; // Affichage code html dans echo en appelant la variable
                      ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>



              <div class="col-md-4"><!--Présentation Humidite-->
                <div style="text-align:center;color:#00c0ef;font-size:30px;"><b>Humidité</b></div>
                <div class="col-md-12">
                <div class="card">

                  <div class="head" style="background-color:#00c0ef;"><!--Dernière Humidite-->
                    <h1>
                      <?php
                        $resultHumiLastUnique = mysqli_fetch_array($resultHumiLastUnique);
                        echo '<b>'.$resultHumiLastUnique["valeur"]." %</b>"; // Affichage code html dans echo en appelant la variable
                      ?>
                    </h1>
                  </div>

                  <div class="col-md-4"><!--Humidite Min-->
                    <div class="littlebox2">
                      <p>Minimum</p>
                      <?php
                        $miniHumi = mysqli_fetch_array($miniHumi);
                        echo '<p><b>'.round($miniHumi["MIN(valeur)"],2)." %</b></p>"; // Affichage code html dans echo en appelant la variable
                      ?>
                    </div>
                  </div>

                  <div class="col-md-4"><!--Humidite Moy-->
                    <div class="littlebox2">
                      <p>Moyenne</p>
                      <?php
                        $moyenneHumi = mysqli_fetch_array($moyenneHumi);
                        echo '<p><b> '.round($moyenneHumi["AVG(valeur)"],2).' %</b></p>'; // Affichage code html dans echo en appelant la variable
                      ?>
                    </div>
                  </div>

                  <div class="col-md-4"><!--Humidite Max-->
                    <div class="littlebox2">
                      <p>Maximum</p>
                      <?php
                        $maxiHumi= mysqli_fetch_array($maxiHumi);
                        echo '<p><b> '.round($maxiHumi["MAX(valeur)"],2).' %</b></p>'; // Affichage code html dans echo en appelant la variable
                      ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>




              <div class="col-md-4"><!--Présentation Précipitations-->
                <div style="text-align:center;color:#0073b7;font-size:30px;"><b>Précipitations</b></div>
                <div class="col-md-12">
                <div class="card">

                  <div class="head" style="background-color:#0073b7;">
                    <h1>
                      <?php
                        $resultPreciLastUnique = mysqli_fetch_array($resultPreciLastUnique);
                        if ($resultPreciLastUnique[0] == 0){
                          echo '<b>Non</b>';
                        }
                        else {
                          echo '<b>Oui</b>';
                        }
                      ?>
                    </h1>
                  </div>

                  <div class="col-md-1"></div>
                  <div class="col-md-10"><!--Date Dernière Précipitation-->
                    <div class="littlebox2">
                      <p>Date dernière pluie</p>
                      <?php
                        $miniPreci = mysqli_fetch_array($miniPreci);
                        echo '<p><b>'.$miniPreci["date_heure"]."</b></p>"; // Affichage code html dans echo en appelant la variable
                      ?>
                    </div>
                  </div>
                  <div class="col-md-1"></div>
                </div>
              </div>
            </div>


				<div class="box-body" style="font-size:10px;padding-right:5px;padding-left:5px;">
					<!-- Dépliant des informations sur la Microstation-->
					<button class="collapsible"><b>Informations sur la micro-station</b></button>
						<div class="content">
								<div class="col-md-3" style="padding-top: 20px; padding-bottom: 20px;">
									<?php
										$resultNom2 = mysqli_fetch_array($resultNom2);
										$resultStatut = mysqli_fetch_array($resultStatut);
										echo '<p><strong>Nom :</strong> '.$resultNom2["nom_station"].'</br><strong>Statut :</strong> ';
                                      if($resultStatut["statut"] == 0)
                                      {
                                          echo 'Hors-ligne </p>';
                                      }
                                      else
                                      {
                                          echo 'En ligne </p>';
                                      }
									?>
								</div>
								<div class="col-md-3"  style="padding-top: 20px; padding-bottom: 20px;">
									<?php
										$resultRegion = mysqli_fetch_array($resultRegion);
										$resultDept = mysqli_fetch_array($resultDept);
										echo '<p><strong>Région : </strong>'.$resultRegion["region"]."</br><strong>Département :</strong> ".$resultDept["departement"].'</p>'; // Affichage code html dans echo en appelant la variable
									?>
								</div>
								<div class="col-md-3"  style="padding-top: 20px; padding-bottom: 20px;">
									<?php
										$resultSerie = mysqli_fetch_array($resultSerie);
										$resultDateF = mysqli_fetch_array($resultDateF);
										echo '<p><strong>Identifiant : </strong>'.$idStation."</br><strong>Date de fabrication :</strong> ".$resultDateF["date_fabrication"].'</p>'; // Affichage code html dans echo en appelant la variable
									?>
								</div>
								<div class="col-md-3" style="padding-top: 20px; padding-bottom: 20px;">
									<?php
										$resultCoord = mysqli_fetch_array($resultCoord);
										echo '<p><strong>Latitude : </strong>'.$resultCoord["latitude"].'</br><strong>Longitude :</strong> '.$resultCoord["longitude"].'</p>'; // Affichage code html dans echo en appelant la variable
									?>
								</div>
						</div>
					<p></p>
					</div>
				</div>
		  </div>
    </div>


		<div class="container-fluid animate-bottom" id="myDiv2"> <!--Tronc 2-->
		<div class="jumbotron" style="background-color:rgb(255,255,255);">
			<ul class="nav nav-tabs"><!-- Menu permettant de choisir les types de valeurs -->
			<li class="active"><a data-toggle="tab" href="#home"><b>Températures</b></a></li>
			<li><a data-toggle="tab" href="#menu1"><b>Humidité</b></a></li>
			<li><a data-toggle="tab" href="#menu2"><b>Précipitations</b></a></li>
			<li><a data-toggle="tab" href="#menu3"><b>Tout</b></a></li>
			</ul>
			<strong>
			<div class="tab-content">
			<div id="home" class="tab-pane fade in active">


				<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
				<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
        <!-- graphique de Température -->
				<div id="Temperature" style="min-width: 100px; height: 450px; max-height: 600px; min-height: 300px; margin-bottom: 20; padding-top: 10px; padding-bottom: 10px;"></div>

				<!-- Table dynamique -->
						<div class="row">
							<div class="block">
								<div class="block-header">
                  <h3 class="block-title">Historique des relevés <small>&nbsp;
                    <?php
                      $resultNom3 = mysqli_fetch_array($resultNom3);
                      echo ''.$resultNom3["nom_station"].'';
                    ?>
                </small></h3>
								</div>
								<div class="block-content">
									<table class="table table-bordered table-hover table-striped js-dataTable-full-pagination">
										<thead>
											<tr>
												<th class="text-center" style="width: 2%;">Date - Heure</th>
												<th class="text-center" style="width: 2%;">Valeur relevée</th>

											</tr>
										</thead>
										<tbody><!-- Affichage des dates et de leurs valeurs dans la table(par ordre décroissant de dates) -->
											<?php
												while($row = mysqli_fetch_array($histoTemp))
												{
													 echo '
													 <tr>
														<td>'.$row["date_heure"].'</td>
														<td>'.$row["valeur"].' °C </td>
													 </tr>
													 ';
												}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
			</div>

			<div id="menu1" class="tab-pane fade">

				<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
				<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
        <!-- graphique d'Humidité -->
        <div id="Humidite" style="min-width: 100px; height: 450px; max-height: 600px; min-height: 300px; margin-bottom: 20; padding-top: 10px; padding-bottom: 10px;"></div>

				<!-- Table dynamique -->
						<div class="row">
							<div class="block">
								<div class="block-header">
                  <h3 class="block-title">Historique des relevés <small>&nbsp;
                    <?php
                      $resultNom4 = mysqli_fetch_array($resultNom4);
                      echo ''.$resultNom4["nom_station"].'';
                    ?>
                </small></h3>
								</div>
								<div class="block-content">

									<table class="table table-bordered table-hover table-striped js-dataTable-full-pagination">
										<thead>
											<tr>
												<th class="text-center" style="width: 2%;">Date - Heure</th>
												<th class="text-center" style="width: 2%;">Valeur relevée</th>

											</tr>
										</thead>
										<tbody><!-- Affichage des dates et de leurs valeurs dans la table(par ordre décroissant de dates) -->
											<?php
												while($row = mysqli_fetch_array($histoHumi))
												{
													 echo '
													 <tr>
														<td>'.$row["date_heure"].'</td>
														<td>'.$row["valeur"].' % </td>
													 </tr>
													 ';
												}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
			</div>

			<div id="menu2" class="tab-pane fade">
				<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
				<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
        <!-- graphique de précipitation -->
        <div id="Precipitation" style="min-width: 100px; height: 450px; max-height: 500px; min-height: 300px; margin-bottom: 20; padding-top: 10px; padding-bottom: 10px;"></div>

				<!-- Table dynamique -->
						<div class="row">
							<div class="block">
								<div class="block-header">
									<h3 class="block-title">Historique des relevés <small>&nbsp;
                    <?php
                      $resultNom5 = mysqli_fetch_array($resultNom5);
                      echo ''.$resultNom5["nom_station"].'';
                    ?>
                </small></h3>
								</div>
								<div class="block-content">
									<table class="table table-bordered table-hover table-striped js-dataTable-full-pagination">
										<thead>
											<tr>
												<th class="text-center" style="width: 2%;">Date - Heure</th>
												<th class="text-center" style="width: 2%;">Valeur relevée</th>
											</tr>
										</thead>
                    <tbody><!-- Affichage des dates et de leurs valeurs dans la table(par ordre décroissant de dates) -->
                      <?php
                        while($row = mysqli_fetch_array($histoPreci))
                        {
                          if ($row["valeur"] >= 1){
                           echo '
                           <tr>
                            <td>'.$row["date_heure"].'</td>
                            <td>Oui</td>
                           </tr>
                           ';
                         }

                         else {
                          echo '
                          <tr>
                           <td>'.$row["date_heure"].'</td>
                           <td>Non</td>
                          </tr>
                          ';
                        }

                        }
                      ?>
                    </tbody>
									</table>
								</div>
							</div>
						</div>
			</div>

			<div id="menu3" class="tab-pane fade">
        <!-- graphique de toutes les données -->
				<div id="Tout" style="min-width: 100px; height: 450px; max-height: 500px; min-height: 300px; margin-bottom: 20; padding-top: 10px; padding-bottom: 10px;"></div>

        <!-- Table dynamique -->
            <div class="row">
              <div class="block">
                <div class="block-header">
                  <h3 class="block-title">Trames de la Micro-Station <small>&nbsp;
                </small></h3>
            </div>
          <div class="block-content">
          <table class="table table-bordered table-hover table-striped js-dataTable-full-pagination">
            <thead>
              <tr>
                <th class="text-center" >id_message</th>
                <th class="text-center" >DT_serveur</th>
                <th class="text-center" >ID</th>
                <th class="text-center" >IDp</th>
                <th class="text-center" >TS</th>
                <th class="text-center" >DT</th>
                <th class="text-center" >D1</th>
                <th class="text-center" >D2</th>
                <th class="text-center" >D3</th>
                <th class="text-center" >Source</th>
              </tr>
            </thead>
            <tbody><!-- Affichage des valeurs selosn les colonnes correspondantes dans la table(par ordre décroissant de dates) -->
              <?php
                while($row = mysqli_fetch_array($Tout))
                {
                   echo '
                    <tr>
                      <td>'.$row["id_message"].'</td>
                      <td>'.$row["DT_serveur"].'</td>
                      <td>'.$row["ID"].'</td>
                      <td>'.$row["IDp"].'</td>
                      <td>'.$row["TS"].'</td>
                      <td>'.$row["DT"].'</td>
                      <td style="color:#f39c12;">'.$row["D1"].'</td>
                      <td style="color:#00c0ef;">'.$row["D2"].'</td>
                      <td style="color:#0073b7;">'.$row["D3"].'</td>
                      <td>'.$row["Source"].'</td>
                    </tr>
                   ';
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    </div>

        </div>
				</div>
			</strong>
			</div>
		</strong>
</div>


<!-- Menu de navigation rapide géré dynamiquement -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" style="text-align:center;font-size:20px;">Liste des Micro-Stations</h5>

      </div>

      <!-- Catégorie EN LIGNE -->
      <!-- Récupération de toutes les stations en ligne et affichage de petits blocs correpondant à chacune d'elles -->
      <div class="col-xs-6">
        <div style="width: 100%;background-color: white;padding: 20px;color: #72b348;font-size: 15px;margin-top:2px;margin-bottom:2px;border-radius: 5px;text-align:center;"><b>En Ligne</b></div>
      <?php

        $totalMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 1") or die('erreur requete 222');
        $row_cnt = mysqli_num_rows($totalMS);
        mysqli_free_result($totalMS);

        $nombreMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 1") or die('erreur requete 223');
        $i=1;

        while(($row = mysqli_fetch_array($nombreMS)) && ($i<=$row_cnt))
        {
          $queryNom11 = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$row[0];
          $resultNom11 = mysqli_query($connect,$queryNom11) or die('erreur 4');
          $resultNom11 = mysqli_fetch_array($resultNom11);
          mysqli_free_result($queryNom11);
      ?>
      <!-- Bloc d'accès rapide a la Microstation -->
      <div class="col-xs-12" style="text-align:center;">
        <div style="background-color: #ededed;border-radius: 5px;padding: 7px;margin: 3px 5px;cursor: pointer;" onclick="location.href='indexMicroStation.php?idStation=<?php printf("%d",$row[0]);?>';"><a style="color:grey"><b><?php echo ''.$resultNom11["nom_station"].'';?></b></br><?php printf("%d",$row[0]);?></a></div>
      </div>

      <?php
      $i=$i++;
        }
      ?>
      </div>


      <!-- Catégorie HORS LIGNE -->
      <!-- Récupération de toutes les stations hors ligne et affichage de petits blocs correpondant à chacune d'elles -->
      <div class="col-xs-6">
        <div style="width: 100%;background-color: white;padding: 20px;color: #e10500;font-size: 15px;margin-top:2px;margin-bottom:2px;border-radius: 5px;text-align:center;"><b>Hors Ligne</b></div>

      <?php

        $totalMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 0") or die('erreur requete 222');
        $row_cnt = mysqli_num_rows($totalMS);
        mysqli_free_result($totalMS);

        $nombreMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 0") or die('erreur requete 223');
        $i=1;

        while(($row = mysqli_fetch_array($nombreMS)) && ($i<=$row_cnt))
        {
          $queryNom12 = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$row[0];
          $resultNom12 = mysqli_query($connect,$queryNom12) or die('erreur 4');
          $resultNom12 = mysqli_fetch_array($resultNom12);
          mysqli_free_result($queryNom12);
      ?>

      <!-- Bloc d'accès rapide a la Microstation -->
      <div class="col-xs-12" style="text-align:center;">
        <div style="background-color: #ededed;border-radius: 5px;padding: 7px;margin: 3px 5px;cursor: pointer;" onclick="location.href='indexMicroStation.php?idStation=<?php printf("%d",$row[0]);?>';"><a style="color:grey"><b><?php echo ''.$resultNom12["nom_station"].'';?></b></br><?php printf("%d",$row[0]);?></a></div>
      </div>

      <?php
      $i=$i++;
        }
      ?>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" style="color:white;background-color:#00a1da;width:100%;margin-top:20px;"><b>Fermer</b></button>
      </div>
    </div>
  </div>
</div>


    <script>
      [].slice.call( document.querySelectorAll( '.dotstyle > ul' ) ).forEach( function( nav ) {
        new DotNav( nav, {
          callback : function( idx ) {
            //console.log( idx )
          }
        } );
      } );
    </script>

		<!-- DataTable -->
		<script src="assets/js/core/jquery.min.js"></script>
		<script src="assets/js/pages/base_tables_datatables.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>


		<!-- script js pour les graphiques highcharts -->
		<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
		<script src="https://code.highcharts.com/highcharts.js"></script>
		<script src="https://code.highcharts.com/highcharts-more.js"></script>
		<script src="https://code.highcharts.com/modules/exporting.js"></script>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
		<script src="datatables/jquery.dataTables.js"></script>

    <!-- Permet d'ouvrir ou fermer le panneau d'information, lorsque l'événement onclick est entendu par le listenner -->
		<script>
		var coll = document.getElementsByClassName("collapsible");
		var i;

		for (i = 0; i < coll.length; i++) {
			coll[i].addEventListener("click", function() {
				this.classList.toggle("actives");
				var content = this.nextElementSibling;
				if (content.style.maxHeight){
					content.style.maxHeight = null;
				} else {
					content.style.maxHeight = content.scrollHeight + "px";
				}
			});
		}
		</script>

    <script> //pour le loader
    var myVar;

    function myFunction() {
        myVar = setTimeout(showPage, 1000); //temps en ([secondes]000)
    }

    function showPage() {
      document.getElementById("loader").style.display = "none";
      document.getElementById("loader2").style.display = "none";
      document.getElementById("myDiv").style.display = "block";
      document.getElementById("myDiv2").style.display = "block";
    }
    </script>

	<script> //pour le graphique Température
	Highcharts.chart('Temperature', {
			chart: {
					type: 'spline'
			},
			title: {
					text: 'Températures'
			},

			xAxis: {
					categories: [
				<?php
					while($row = mysqli_fetch_array($resultTemp2))
					{
				?>
					"<?php echo($row[1])?>",
				<?php
					}
				?>
			]
			},
			yAxis: {
					title: {
							text: 'Températures (°C)'
					}
			},
			plotOptions: {
					line: {
							dataLabels: {
									enabled: true
							},
							enableMouseTracking: false
					}
			},
			series: [{
					name: 'Températures',
					data: [
				<?php
					while($row = mysqli_fetch_array($resultTemp1))
					{
				?>
					<?php echo($row[0])?>,
				<?php
					}
				?>
			]
			}]
	});
	</script>

	<script> //pour le graphique Humidité
	Highcharts.chart('Humidite', {
			chart: {
					type: 'spline'
			},
			title: {
					text: 'Humidité'
			},

			xAxis: {
					categories: [
				<?php
					while($row = mysqli_fetch_array($resultHumi1))
					{
				?>
					"<?php echo($row[1])?>",
				<?php
					}
				?>
			]
			},
			yAxis: {
					title: {
							text: 'Humidité'
					}
			},
			plotOptions: {
					line: {
							dataLabels: {
									enabled: true
							},
							enableMouseTracking: false
					}
			},
			series: [{
					name: 'Humidité',
					data: [
				<?php
					while($row = mysqli_fetch_array($resultHumi2))
					{
				?>
					<?php echo($row[0])?>,
				<?php
					}
				?>
			]
			}]
	});
	</script>

	<script> //pour le graphique Précipitations
	Highcharts.chart('Precipitation', {
			chart: {
					type: 'column'
			},
			title: {
					text: 'Précipitations'
			},

			xAxis: {
					categories: [
				<?php
					while($row = mysqli_fetch_array($resultPreci1))
					{
				?>
					"<?php echo($row[1])?>",
				<?php
					}
				?>
			]
			},
			yAxis: {
					title: {
							text: 'Précipitations'
					}
			},
			plotOptions: {
					line: {
							dataLabels: {
									enabled: true
							},
							enableMouseTracking: false
					}
			},
			series: [{
					name: 'Précipitations',
					data: [
				<?php
					while($row = mysqli_fetch_array($resultPreci2))
					{
				?>

	  <?php
		if ($row[0] >= 1){
		  echo '1';
		}
		else {
		  echo '0';
		}
	  ?>,

				<?php
					}
				?>
			]
			}]
	});
	</script>




	<script> //pour le graphique "Tout"
	Highcharts.chart('Tout', {
		chart: {
				zoomType: 'xy'
		},
		title: {
				text: 'Ensemble des données'
		},
		xAxis: [{
			categories: [
			<?php
				while($row = mysqli_fetch_array($resultTemp4))
				{
			?>
				"<?php echo($row[1])?>",
			<?php
				}
			?>
		],
				crosshair: true
		}],
		yAxis: [{ // Primary yAxis
				labels: {
						format: '{value}',
						style: {
								color: Highcharts.getOptions().colors[2]
						}
				},
				title: {
						text: 'Températures',
						style: {
								color: Highcharts.getOptions().colors[2]
						}
				},
				opposite: true

		}, { // Secondary yAxis
				gridLineWidth: 0,
				title: {
						text: 'Précipitations',
						style: {
								color: Highcharts.getOptions().colors[0]
						}
				},
				labels: {
						format: '{value}',
						style: {
								color: Highcharts.getOptions().colors[0]
						}
				}

		}, { // Tertiary yAxis
				gridLineWidth: 0,
				title: {
						text: 'Humidité',
						style: {
								color: Highcharts.getOptions().colors[1]
						}
				},
				labels: {
						format: '{value}',
						style: {
								color: Highcharts.getOptions().colors[1]
						}
				},
				opposite: true
		}],
		tooltip: {
				shared: true
		},
		legend: {
				layout: 'vertical',
				align: 'left',
				x: 80,
				verticalAlign: 'top',
				y: 55,
				floating: true,
				backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
		},
		series: [{
				name: 'Précipitations',
				type: 'column',
				yAxis: 1,
				data: [
				<?php
					while($row = mysqli_fetch_array($resultPreci3))
					{
				?>
	  <?php
		if ($row[0] >= 1){
		  echo '1';
		}
		else {
		  echo '0';
		}
	  ?>,

				<?php
					}
				?>
			],
				tooltip: {
						valueSuffix: ''
				}

		}, {
				name: 'Humidité',
				type: 'spline',
				yAxis: 2,
				data: [
				<?php
					while($row = mysqli_fetch_array($resultHumi3))
					{
				?>
					<?php echo($row[0])?>,
				<?php
					}
				?>
			],
				marker: {
						enabled: false
				},
				dashStyle: 'shortdot',
				tooltip: {
						valueSuffix: ' %'
				}

		}, {
				name: 'Températures',
				type: 'spline',
				data: [
					<?php
						while($row = mysqli_fetch_array($resultTemp3))
						{
					?>
						<?php echo($row[0])?>,
					<?php
						}
					?>
				],
				tooltip: {
						valueSuffix: ' °C'
				}
		}]
	});
	</script>


	</body>
</html>
