<?php

$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";

$connect = mysqli_connect($host,$user,$passwd);

mysqli_select_db($connect, $bdd);

$resultat = mysqli_query($connect, 'UPDATE Station SET Station.statut = 0');

mysqli_free_result($resultat);
 
mysqli_close($connect);
?>