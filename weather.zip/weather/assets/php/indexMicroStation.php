<?php
// Déclaration des paramètres de connexion
$host = "localhost";
$user = "root";
$bdd = "btslimaypvsn2017";
$passwd  = "root";
$idStation = 1;  		// ID Micro-station

// Connexion au serveur
$connect = mysqli_connect($host,$user,$passwd) or die("erreur de connexion au serveur");

mysqli_select_db($connect, $bdd) or die("erreur de connexion a la base de donnees");

//////// Creation des requetes ////////


//Dernière donnée enregistrée (par type de mesure)
$resultTempLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
$resultHumiLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Humidite") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
$resultPreciLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Precipitation") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');

//Dernière précipitation pour changer l'icone de météo
$resultPreciLastUnique1 = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Precipitation") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');

//Historiques des valeurs par date, en fonction de leur type de données
$histoTemp = mysqli_query($connect, 'SELECT * FROM Mesure WHERE Mesure.type_mesure = "Temperature" AND Mesure.id_station = '.$idStation.' ORDER BY Mesure.date_heure DESC') or die('erreur historique');
$histoHumi = mysqli_query($connect, 'SELECT * FROM Mesure WHERE Mesure.type_mesure = "Humidite" AND Mesure.id_station = '.$idStation.' ORDER BY Mesure.date_heure DESC') or die('erreur historique');
$histoPreci = mysqli_query($connect, 'SELECT * FROM Mesure WHERE Mesure.type_mesure = "Precipitation" AND Mesure.id_station = '.$idStation.' ORDER BY Mesure.date_heure DESC') or die('erreur historique');

//12 dernières valeurs [Températures et DateHeure]
$resultTemp1 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Temperature")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

$resultTemp2 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Temperature")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

$resultTemp3 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Temperature")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

$resultTemp4 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Temperature")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

//12 dernières valeurs [Humidité et DateHeure]
$resultHumi1 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Humidite")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

$resultHumi2 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Humidite")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

$resultHumi3 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Humidite")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

//12 dernières valeurs [Précipitations et DateHeure]
$resultPreci1 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Precipitation")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

$resultPreci2 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Precipitation")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

$resultPreci3 = mysqli_query($connect, 'SELECT t.* FROM  (
    SELECT q.* FROM  (
        SELECT valeur, date_heure, type_mesure
        FROM mesure, station
        WHERE (Mesure.id_station = Station.id_station)
        AND (Station.id_station = '.$idStation.')
        AND (Mesure.type_mesure = "Precipitation")) AS q
    ORDER BY q.date_heure  DESC LIMIT 0,12) AS t
ORDER BY t.date_heure ASC LIMIT 0,12;') or die('erreur 1');

//Informations sur la Micro-Station
$queryNom = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
$resultNom = mysqli_query($connect,$queryNom) or die('erreur 4');

$queryStatut = "SELECT Station.statut FROM Station WHERE Station.id_station = ".$idStation;
$resultStatut = mysqli_query($connect,$queryStatut) or die('erreur 5');

$queryCoord = "SELECT Station.latitude, Station.longitude FROM Station WHERE Station.id_station = ".$idStation;
$resultCoord = mysqli_query($connect,$queryCoord) or die('erreur 6');

$queryRegion = "SELECT Station.region FROM Station WHERE Station.id_station = ".$idStation;
$resultRegion = mysqli_query($connect,$queryRegion) or die('erreur 7');

$queryDept = "SELECT Station.departement FROM Station WHERE Station.id_station = ".$idStation;
$resultDept = mysqli_query($connect,$queryDept) or die('erreur 8');

$querySerie = "SELECT Station.num_serie FROM Station WHERE Station.id_station = ".$idStation;
$resultSerie = mysqli_query($connect,$querySerie) or die('erreur 9');

$queryDateF = "SELECT Station.date_fabrication FROM Station WHERE Station.id_station = ".$idStation;
$resultDateF = mysqli_query($connect,$queryDateF) or die('erreur 10');



//Requêtes de l'ancien site
/*
  $resultTemp7 = mysqli_query($connect, 'SELECT Mesure.valeur, date_heure FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,12;') or die('erreur 1');
  $resultTemp8 = mysqli_query($connect, 'SELECT Mesure.valeur, date_heure FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,12;') or die('erreur 1');

  $queryHumi = "SELECT Mesure.valeur FROM Mesure WHERE Mesure.type_mesure = 'Humidite' AND Mesure.id_station = ".$idStation." ORDER BY id_mesure DESC LIMIT 0,1";
  $resultHumi = mysqli_query($connect,$queryHumi) or die('erreur 2');

  $queryPreci = "SELECT Mesure.valeur FROM Mesure WHERE Mesure.type_mesure = 'Precipitation' AND Mesure.id_station = ".$idStation." ORDER BY id_mesure DESC LIMIT 0,1";
  $resultPreci = mysqli_query($connect,$queryPreci) or die('erreur 3');
*/


?>
