<!DOCTYPE html>

<?php
// Déclaration des paramètres de connexion
$host = "btslimaypvsn2017.mysql.db";
$user = "btslimaypvsn2017";
$bdd = "btslimaypvsn2017";
$passwd  = "Lapin2Blanc";

// Connexion au serveur
$connect = mysqli_connect($host,$user,$passwd) or die("erreur de connexion au serveur");

mysqli_select_db($connect, $bdd) or die("erreur de connexion a la base de donnees");

?>


<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Accueil</title>
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
		<link rel="icon" href="/favicon.ico" type="image/x-icon">

		<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">

		<script src="js/modernizr.custom.js"></script>



		<link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.1/dist/leaflet.css"
      integrity="sha512-Rksm5RenBEKSKFjgI3a41vrjkw4EVPlJ3+OiI65vTjIdo9brlAacEuKOiQ5OFh7cOI1bkDwLqdLw3Zg0cRJAAQ=="
      crossorigin=""/>


      <!-- Make sure you put this AFTER Leaflet's CSS -->
		<script src="https://unpkg.com/leaflet@1.3.1/dist/leaflet.js"
		 integrity="sha512-/Nsx9X4HebavoBvEBuyp3I7od5tA0UzAxs+j83KgC8PU0kgB4XiK4Lfe4y4cgBtaRJQEIFCW+oC506aPT2L1zw=="
		 crossorigin=""></script>




	</head>
	<body>

		<div class="container demo-3">
			<ul class="grid cs-style-4">
			<div style="color:white;font-weight:bold;font-size:30px;padding-bottom:20px;">Projet : Collecte de Données Météo Agricoles</div>
			<div class="Ligne"><b>En Ligne</b></div>
			<?php

				$totalMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 1") or die('erreur requete 222');
				$row_cnt = mysqli_num_rows($totalMS);
				mysqli_free_result($totalMS);

				$nombreMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 1") or die('erreur requete 223');
				$i=1;

				while(($row = mysqli_fetch_array($nombreMS)) && ($i<=$row_cnt))
				{ $idStation = $row[0];

					//////////////////////////////////////////////
					$resultTempLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
					$resultHumiLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Humidite") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
					$resultPreciLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Precipitation") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');


					$queryNom = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
					$resultNom = mysqli_query($connect,$queryNom) or die('erreur 4');
					mysqli_free_result($queryNom);

					$queryNom1 = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
					$resultNom1 = mysqli_query($connect,$queryNom1) or die('erreur 4');
					mysqli_free_result($queryNom1);


					$queryCoord = "SELECT Station.latitude, Station.longitude FROM Station WHERE Station.id_station = ".$idStation;
					$resultCoord = mysqli_query($connect,$queryCoord) or die('erreur 6');
					mysqli_free_result($queryCoord);
					//////////////////////////////////////////////

			?>

			<li>
				<figure style="box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);">
					<div>

						<div style="padding:80px 1px;background-image: url('images/blockback.png');background-repeat: no-repeat;background-size: cover;text-align:center;font-size:27px;">
							<?php
								$resultNom1 = mysqli_fetch_array($resultNom1);
								echo '<div style="color:#646464;">'.$resultNom1["nom_station"].'</div><div style="color:#646464;">Id : '.$idStation.'</div>'; // Affichage code html dans echo en appelant la variable
							?>
						</div>

					</div>
					<figcaption>
						<h3 style="padding-bottom:13px">
							<?php
								$resultNom = mysqli_fetch_array($resultNom);
								echo ''.$resultNom["nom_station"].''; // Affichage code html dans echo en appelant la variable
							?>
						</h3>
					</br>
				<div style="color:#3c4a50;">
					<?php
						$resultTempLastUnique = mysqli_fetch_array($resultTempLastUnique);
						echo '<strong>Température : </strong><span style="float:right;">'.$resultTempLastUnique["valeur"]." °C</span>"; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				<div style="color:#3c4a50;">
					<?php
						$resultHumiLastUnique = mysqli_fetch_array($resultHumiLastUnique);
						echo '<strong>Humidité :</strong> <span style="float:right;"> '.$resultHumiLastUnique["valeur"].' %</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				<div style="color:#3c4a50;">
					<?php
						$resultPreciLastUnique = mysqli_fetch_array($resultPreciLastUnique);
						echo '<strong>Précipitation :</strong> <span style="float:right;"> '.$resultPreciLastUnique["valeur"].' mm</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
				</br>
				<div>
					<?php
						$resultCoord = mysqli_fetch_array($resultCoord);
						$resultSerie = mysqli_fetch_array($resultSerie);
						echo '<strong>Latitude : </strong><span style="float:right;">'.$resultCoord["latitude"].'</span></br><strong>Longitude :</strong><span style="float:right;">'.$resultCoord["longitude"]."</span></br><strong>Identification :</strong><span style='float:right;'>".$idStation.'</span>'; // Affichage code html dans echo en appelant la variable
					?>
				</div>
						<a onclick="location.href='indexMicroStation.php?idStation=<?php printf("%d",$row[0]);?>';" style="cursor: pointer;">Voir</a>
					</figcaption>
				</figure>
			</li>

			<?php
				$i=$i++;
				mysqli_free_result($resultNom);
				mysqli_free_result($resultStatut);
				mysqli_free_result($resultCoord);
				mysqli_free_result($resultDateF);
				mysqli_free_result($idStation);
					}
			?>

<div class="Ligne" style="color:#f36a10;"><b>Hors Ligne</b></div>

<?php

	$totalMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 0") or die('erreur requete 222');
	$row_cnt = mysqli_num_rows($totalMS);
	mysqli_free_result($totalMS);

	$nombreMS = mysqli_query($connect, "SELECT * FROM Station WHERE Station.statut = 0") or die('erreur requete 223');
	$i=1;

	while(($row = mysqli_fetch_array($nombreMS)) && ($i<=$row_cnt))
	{ $idStation = $row[0];

		//////////////////////////////////////////////
		$resultTempLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Temperature") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
		$resultHumiLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Humidite") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');
		$resultPreciLastUnique = mysqli_query($connect, 'SELECT Mesure.valeur FROM Mesure,Station WHERE (Mesure.id_station = Station.id_station) AND (Mesure.type_mesure = "Precipitation") AND (Station.id_station = '.$idStation.') ORDER BY Mesure.date_heure DESC LIMIT 0,1;') or die('erreur 1');


		$queryNom = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
		$resultNom = mysqli_query($connect,$queryNom) or die('erreur 4');
		mysqli_free_result($queryNom);

		$queryNom1 = "SELECT Station.nom_station FROM Station WHERE Station.id_station = ".$idStation;
		$resultNom1 = mysqli_query($connect,$queryNom1) or die('erreur 4');
		mysqli_free_result($queryNom1);


		$queryCoord = "SELECT Station.latitude, Station.longitude FROM Station WHERE Station.id_station = ".$idStation;
		$resultCoord = mysqli_query($connect,$queryCoord) or die('erreur 6');
		mysqli_free_result($queryCoord);


		//////////////////////////////////////////////
?>

<li>
	<figure style="box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);">
		<div>

			<div style="padding:80px 1px;background-image: url('images/blockback.png');background-repeat: no-repeat;background-size: cover;text-align:center;font-size:27px;">
				<?php
					$resultNom1 = mysqli_fetch_array($resultNom1);
					echo '<div style="color:#646464;">'.$resultNom1["nom_station"].'</div><div style="color:#646464;">Id : '.$idStation.'</div>'; // Affichage code html dans echo en appelant la variable
				?>
			</div>

		</div>
		<figcaption>
			<h3 style="padding-bottom:13px">
				<?php
					$resultNom = mysqli_fetch_array($resultNom);
					echo ''.$resultNom["nom_station"].''; // Affichage code html dans echo en appelant la variable
				?>
			</h3>
		</br>
	<div style="color:#3c4a50;">
		<?php
			$resultTempLastUnique = mysqli_fetch_array($resultTempLastUnique);
			echo '<strong>Température : </strong><span style="float:right;">'.$resultTempLastUnique["valeur"]." °C</span>"; // Affichage code html dans echo en appelant la variable
		?>
	</div>
	<div style="color:#3c4a50;">
		<?php
			$resultHumiLastUnique = mysqli_fetch_array($resultHumiLastUnique);
			echo '<strong>Humidité :</strong> <span style="float:right;"> '.$resultHumiLastUnique["valeur"].' %</span>'; // Affichage code html dans echo en appelant la variable
		?>
	</div>
	<div style="color:#3c4a50;">
		<?php
			$resultPreciLastUnique = mysqli_fetch_array($resultPreciLastUnique);
			echo '<strong>Précipitation :</strong> <span style="float:right;"> '.$resultPreciLastUnique["valeur"].' mm</span>'; // Affichage code html dans echo en appelant la variable
		?>
	</div>
	</br>
	<div>
		<?php
			$resultCoord = mysqli_fetch_array($resultCoord);
			$resultSerie = mysqli_fetch_array($resultSerie);
			echo '<strong>Latitude : </strong><span style="float:right;">'.$resultCoord["latitude"].'</span></br><strong>Longitude :</strong><span style="float:right;">'.$resultCoord["longitude"]."</span></br><strong>Identification :</strong><span style='float:right;'>".$idStation.'</span>'; // Affichage code html dans echo en appelant la variable
		?>
	</div>
			<a onclick="location.href='indexMicroStation.php?idStation=<?php printf("%d",$row[0]);?>';" style="cursor: pointer;">Voir</a>
		</figcaption>
	</figure>
</li>

<?php
	$i=$i++;
	mysqli_free_result($resultNom);
	mysqli_free_result($resultStatut);
	mysqli_free_result($resultCoord);
	mysqli_free_result($resultDateF);
	mysqli_free_result($idStation);
		}
?>


			<div class="Ligne" style="color:#4CAF50;"><b>Carte des Micro-Stations</b></div>

			<!--Cartes
			<iframe src="https://www.google.com/maps/d/embed?mid=1yuqF6pqa5lPvMpRUKBH4ZKwxCqOvjzvh" width="100%" height="600" style="box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);"></iframe>
-->





<div id="mapid"></div>

<script>
	var mymap = L.map('mapid').setView([43.9792, 1.29626], 3);

	<?php

		$totalMS1 = mysqli_query($connect, "SELECT * FROM Station") or die('erreur requete 222');
		$row_cnt1 = mysqli_num_rows($totalMS1);
		mysqli_free_result($totalMS1);

		$nombreMS1 = mysqli_query($connect, "SELECT id_station FROM Station") or die('erreur requete 223');
		$a=1;

		while(($row = mysqli_fetch_array($nombreMS1)) && ($a<=$row_cnt1))
		{	$idStation1 = $row[0];

			$queryCoord11 = "SELECT Station.latitude FROM Station WHERE Station.id_station = ".$idStation1;
			$queryCoord12 = "SELECT Station.longitude FROM Station WHERE Station.id_station = ".$idStation1;
			$queryNom3 = "SELECT nom_station FROM `Station` WHERE id_station = ".$idStation1;

			$resultCoord11 = mysqli_query($connect,$queryCoord11) or die('erreur 611');
			$resultCoord12 = mysqli_query($connect,$queryCoord12) or die('erreur 612');
			$resultNom3 = mysqli_query($connect,$queryNom3) or die('erreur 613');
			//$resultNom3 = mysqli_fetch_array($resultNom3);

			mysqli_free_result($queryCoord11);
			mysqli_free_result($queryCoord12);
			mysqli_free_result($queryNom3);

			$Lat = mysqli_fetch_assoc($resultCoord11);
			$Long = mysqli_fetch_assoc($resultCoord12);
			$RowName = mysqli_fetch_assoc($resultNom3);
	?>

	var Lat = <?php echo $Lat['latitude']; ?>;
	var Long = <?php echo $Long['longitude']; ?>;
	var Id = <?php echo $idStation1; ?>;
	var Name = '<b>' + '<?php echo(''.$RowName["nom_station"].'') ?>' + '</b>';


	var marker = L.marker([Lat, Long]).addTo(mymap).bindPopup(Name + '</br> Id :' + Id).openPopup();


	<?php
		$a=$a++;
		}
	?>

</script>



<script>
		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
				attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
				maxZoom: 18,
				id: 'mapbox.streets',
				accessToken: 'pk.eyJ1IjoiY2xlbWVudGhlcm5hbmRleiIsImEiOiJjamk1eTEycG4wbW44M3FwZnpmYW1naDRuIn0.Cn6ph_v_M3w2FwnLxRQQkQ'
		}).addTo(mymap);
</script>




<div class="Ligne" style="color:grey;"><b>Administrateur</b></div>

			<div class="col-md-6">
				<button class="button" style="vertical-align:middle" onclick="location.href='/formulaire/formulaireAjoutMS.html';"><span>Ajouter une Micro-Station </span></button>
			</div>
			<div class="col-md-6">
				<button class="button two" style="vertical-align:middle" onclick="location.href='/formulaire/Messages.php';"><span>Tous les messages </span></button>
			</div>


			</ul>
		</div><!-- /container -->
	</br>
	</br>
		<script src="js/toucheffects.js"></script>
	</body>
</html>
